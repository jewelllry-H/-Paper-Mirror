/**
 * 译镜 · 共享配置
 * 所有 OpenAI 兼容（/chat/completions）的服务都可以在这里配置。
 */

export const DEFAULT_SETTINGS = Object.freeze({
  provider: 'deepseek',
  baseUrl: 'https://api.deepseek.com/v1',
  apiKey: '',
  appId: '',
  appSecret: '',
  model: 'deepseek-chat',
  targetLang: '简体中文',
  autoTranslate: true,
  concurrency: 2,
  batchChars: 1600,
  fontScale: 1,
  keepGraphics: true,
  translateReferences: false,
  ocrFigures: true,
});

export const TARGET_LANGS = ['简体中文', '繁體中文', '日本語', '한국어'];

export const PROVIDERS = {
  deepseek: {
    label: 'DeepSeek',
    tag: '推荐',
    baseUrl: 'https://api.deepseek.com/v1',
    model: 'deepseek-chat',
    hint: '中文翻译质量好、价格低。翻译一篇 20 页论文通常只需几分钱。',
    keyUrl: 'https://platform.deepseek.com/api_keys',
  },
  siliconflow: {
    label: '硅基流动',
    tag: '免费模型',
    baseUrl: 'https://api.siliconflow.cn/v1',
    model: 'Qwen/Qwen2.5-7B-Instruct',
    hint: '国内可访问，平台上有若干免费额度模型，可在模型广场自行选择。',
    keyUrl: 'https://cloud.siliconflow.cn/account/ak',
  },
  zhipu: {
    label: '智谱 GLM',
    tag: '免费额度',
    baseUrl: 'https://open.bigmodel.cn/api/paas/v4',
    model: 'glm-4-flash',
    hint: 'glm-4-flash 提供免费额度，适合日常文献翻译。',
    keyUrl: 'https://bigmodel.cn/usercenter/proj-mgmt/apikeys',
  },
  moonshot: {
    label: 'Moonshot',
    tag: '',
    baseUrl: 'https://api.moonshot.cn/v1',
    model: 'moonshot-v1-8k',
    hint: '长文本表现稳定，适合篇幅较长的论文。',
    keyUrl: 'https://platform.moonshot.cn/console/api-keys',
  },
  openai: {
    label: 'OpenAI',
    tag: '',
    baseUrl: 'https://api.openai.com/v1',
    model: 'gpt-4o-mini',
    hint: '需要可访问 OpenAI 的网络环境。',
    keyUrl: 'https://platform.openai.com/api-keys',
  },
  baidu: {
    label: '百度翻译',
    tag: '免费额度',
    baseUrl: '',
    model: '',
    hint: '百度翻译开放平台通用文本翻译，需要 AppID 和密钥；有免费额度（以官网为准），QPS 较低，适合中小篇幅。',
    keyUrl: 'https://fanyi-api.baidu.com/',
  },
  mymemory: {
    label: 'MyMemory',
    tag: '无需 Key',
    baseUrl: '',
    model: '',
    hint: '免费公共翻译接口，无需密钥，但每天字符数有限、速度较慢，适合短文档或试用。',
    keyUrl: 'https://mymemory.translated.net/doc/spec.php',
  },
  custom: {
    label: '自定义',
    tag: '',
    baseUrl: '',
    model: '',
    hint: '填写任意兼容 OpenAI /chat/completions 协议的服务地址与模型名。',
    keyUrl: '',
  },
};

export function normalizeBaseUrl(url = '') {
  return String(url)
    .trim()
    .replace(/\/+$/, '')
    .replace(/\/chat\/completions$/i, '');
}

export function providerKeyOf(baseUrl) {
  const normalized = normalizeBaseUrl(baseUrl);
  for (const [key, preset] of Object.entries(PROVIDERS)) {
    if (preset.baseUrl && normalizeBaseUrl(preset.baseUrl) === normalized) return key;
  }
  return 'custom';
}
