import {
  DEFAULT_SETTINGS,
  PROVIDERS,
  TARGET_LANGS,
  normalizeBaseUrl,
  providerKeyOf,
} from './config.js';
import md5 from './lib/md5.js';

const $ = (id) => document.getElementById(id);

const ui = {
  welcome: $('welcome'),
  providers: $('providers'),
  providerNote: $('providerNote'),
  baseUrlField: $('baseUrlField'),
  baseUrl: $('baseUrl'),
  baseUrlHint: $('baseUrlHint'),
  apiKeyField: $('apiKeyField'),
  apiKey: $('apiKey'),
  toggleKey: $('toggleKey'),
  keyLink: $('keyLink'),
  baiduFields: $('baiduFields'),
  appId: $('appId'),
  appSecret: $('appSecret'),
  toggleSecret: $('toggleSecret'),
  baiduKeyLink: $('baiduKeyLink'),
  modelField: $('modelField'),
  model: $('model'),
  targetLang: $('targetLang'),
  testBtn: $('testBtn'),
  testResult: $('testResult'),
  autoTranslate: $('autoTranslate'),
  keepGraphics: $('keepGraphics'),
  translateReferences: $('translateReferences'),
  ocrFigures: $('ocrFigures'),
  concurrency: $('concurrency'),
  batchChars: $('batchChars'),
  fontScale: $('fontScale'),
  saveBtn: $('saveBtn'),
  saveState: $('saveState'),
};

let settings = { ...DEFAULT_SETTINGS };
let activeProvider = 'deepseek';
let saveTimer = 0;

init().catch((err) => {
  console.error(err);
  showSaveState(`设置页初始化失败：${err.message}`, true);
});

async function init() {
  const stored = await chrome.storage.local.get(DEFAULT_SETTINGS);
  settings = { ...DEFAULT_SETTINGS, ...stored };

  activeProvider =
    settings.provider && PROVIDERS[settings.provider]
      ? settings.provider
      : providerKeyOf(settings.baseUrl);

  renderProviderCards();
  renderLanguages();
  fillForm();

  const params = new URLSearchParams(location.search);
  if (params.get('welcome') || !hasUsableConfig(settings, activeProvider)) {
    ui.welcome.hidden = false;
  }

  bindEvents();
}

function renderProviderCards() {
  ui.providers.textContent = '';

  for (const [key, provider] of Object.entries(PROVIDERS)) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'provider-card';
    button.dataset.provider = key;
    button.classList.toggle('is-active', key === activeProvider);

    const name = document.createElement('span');
    name.className = 'provider-name';
    name.textContent = provider.label;

    const tag = document.createElement('span');
    tag.className = 'provider-tag';
    tag.textContent = provider.tag || ' ';

    const check = document.createElement('span');
    check.className = 'provider-check';
    check.textContent = '✓';

    button.append(name, tag, check);
    button.addEventListener('click', () => selectProvider(key));
    ui.providers.appendChild(button);
  }

  updateProviderHint();
}

function renderLanguages() {
  ui.targetLang.textContent = '';
  for (const language of TARGET_LANGS) {
    const option = document.createElement('option');
    option.value = language;
    option.textContent = language;
    ui.targetLang.appendChild(option);
  }
}

function fillForm() {
  ui.baseUrl.value = settings.baseUrl || '';
  ui.apiKey.value = settings.apiKey || '';
  ui.appId.value = settings.appId || '';
  ui.appSecret.value = settings.appSecret || '';
  ui.model.value = settings.model || '';
  ui.targetLang.value = TARGET_LANGS.includes(settings.targetLang)
    ? settings.targetLang
    : '简体中文';
  ui.autoTranslate.checked = Boolean(settings.autoTranslate);
  ui.keepGraphics.checked = settings.keepGraphics !== false;
  ui.translateReferences.checked = Boolean(settings.translateReferences);
  ui.ocrFigures.checked = settings.ocrFigures !== false;
  ui.concurrency.value = String(settings.concurrency || 2);
  ui.batchChars.value = String(settings.batchChars || 1600);
  ui.fontScale.value = String(settings.fontScale || 1);
}

function selectProvider(key) {
  const previous = PROVIDERS[activeProvider];
  const next = PROVIDERS[key];
  if (!next) return;

  activeProvider = key;

  const currentBase = normalizeBaseUrl(ui.baseUrl.value);
  const currentModel = ui.model.value.trim();

  if (
    next.baseUrl &&
    (!currentBase || (previous && currentBase === normalizeBaseUrl(previous.baseUrl)))
  ) {
    ui.baseUrl.value = next.baseUrl;
  }
  if (next.model && (!currentModel || (previous && currentModel === previous.model))) {
    ui.model.value = next.model;
  }

  for (const card of ui.providers.querySelectorAll('.provider-card')) {
    card.classList.toggle('is-active', card.dataset.provider === key);
  }

  updateProviderHint();
  clearTestResult();
}

function updateProviderHint() {
  const provider = PROVIDERS[activeProvider];
  const isBaidu = activeProvider === 'baidu';
  const isMemory = activeProvider === 'mymemory';
  const isApiProvider = !isBaidu && !isMemory;

  ui.baseUrlField.hidden = !isApiProvider;
  ui.apiKeyField.hidden = !isApiProvider;
  ui.modelField.hidden = !isApiProvider;
  ui.baiduFields.hidden = !isBaidu;

  ui.providerNote.hidden = isApiProvider || !provider?.hint;
  ui.providerNote.textContent = provider?.hint || '';

  if (isApiProvider) {
    ui.baseUrlHint.textContent =
      provider?.hint ||
      '填写服务商提供的 OpenAI 兼容接口地址，例如 https://api.example.com/v1。';

    if (provider?.keyUrl) {
      ui.keyLink.href = provider.keyUrl;
      ui.keyLink.hidden = false;
    } else {
      ui.keyLink.hidden = true;
      ui.keyLink.removeAttribute('href');
    }
  } else {
    ui.keyLink.hidden = true;
    ui.keyLink.removeAttribute('href');
  }

  if (isBaidu) {
    ui.baiduKeyLink.href = provider?.keyUrl || 'https://fanyi-api.baidu.com/';
  }
}

function hasUsableConfig(config, provider) {
  if (provider === 'mymemory') return true;
  if (provider === 'baidu') return Boolean(config.appId && config.appSecret);
  return Boolean(config.apiKey);
}

function bindEvents() {
  ui.toggleKey.addEventListener('click', () => {
    const isPassword = ui.apiKey.type === 'password';
    ui.apiKey.type = isPassword ? 'text' : 'password';
    ui.toggleKey.textContent = isPassword ? '隐藏' : '显示';
  });

  ui.toggleSecret.addEventListener('click', () => {
    const isPassword = ui.appSecret.type === 'password';
    ui.appSecret.type = isPassword ? 'text' : 'password';
    ui.toggleSecret.textContent = isPassword ? '隐藏' : '显示';
  });

  ui.testBtn.addEventListener('click', testConnection);
  ui.saveBtn.addEventListener('click', saveSettings);

  for (const input of [ui.baseUrl, ui.apiKey, ui.model, ui.appId, ui.appSecret]) {
    input.addEventListener('input', clearTestResult);
  }
}

async function saveSettings() {
  const config = readForm();
  const isApiProvider = !['baidu', 'mymemory'].includes(activeProvider);

  if (isApiProvider) {
    if (!config.baseUrl) {
      showSaveState('请填写接口地址', true);
      return;
    }

    if (!isValidUrl(config.baseUrl)) {
      showSaveState('接口地址格式不正确', true);
      return;
    }

    if (!config.model) {
      showSaveState('请填写模型名称', true);
      return;
    }
  }

  if (activeProvider === 'baidu') {
    if (!config.appId || !config.appSecret) {
      showSaveState('请填写百度 AppID 和密钥', true);
      return;
    }
  }

  if (isApiProvider && !config.apiKey) {
    showSaveState('已保存。填入 API Key 后才能开始翻译。', true);
  } else {
    showSaveState('已保存 ✓');
  }

  await chrome.storage.local.set(config);
  settings = { ...config };
  ui.welcome.hidden = true;

  clearTimeout(saveTimer);
  saveTimer = window.setTimeout(() => {
    if (ui.saveState.textContent === '已保存 ✓') ui.saveState.textContent = '';
  }, 2400);
}

function readForm() {
  const fallbackProvider = PROVIDERS[activeProvider];

  const baseUrl =
    normalizeBaseUrl(ui.baseUrl.value) ||
    normalizeBaseUrl(fallbackProvider?.baseUrl || '');

  return {
    provider: activeProvider,
    baseUrl,
    apiKey: ui.apiKey.value.trim(),
    appId: ui.appId.value.trim(),
    appSecret: ui.appSecret.value.trim(),
    model: ui.model.value.trim() || fallbackProvider?.model || '',
    targetLang: ui.targetLang.value || '简体中文',
    autoTranslate: ui.autoTranslate.checked,
    keepGraphics: ui.keepGraphics.checked,
    translateReferences: ui.translateReferences.checked,
    ocrFigures: ui.ocrFigures.checked,
    concurrency: clamp(Number(ui.concurrency.value) || 2, 1, 4),
    batchChars: clamp(Number(ui.batchChars.value) || 1600, 500, 4000),
    fontScale: clamp(Number(ui.fontScale.value) || 1, 0.8, 1.2),
  };
}

async function testConnection() {
  const config = readForm();
  clearTestResult();

  if (activeProvider === 'baidu') {
    await testBaidu(config);
    return;
  }

  if (activeProvider === 'mymemory') {
    await testMyMemory();
    return;
  }

  if (!config.apiKey) {
    setTestResult('请先填写 API Key', 'error');
    return;
  }
  if (!config.baseUrl || !isValidUrl(config.baseUrl)) {
    setTestResult('接口地址不正确', 'error');
    return;
  }
  if (!config.model) {
    setTestResult('请填写模型名称', 'error');
    return;
  }

  ui.testBtn.disabled = true;
  setTestResult('正在连接…', '');

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 25000);
  const startedAt = performance.now();

  try {
    const response = await fetch(`${config.baseUrl}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${config.apiKey}`,
      },
      body: JSON.stringify({
        model: config.model,
        messages: [
          {
            role: 'user',
            content: 'Translate "Hello" into Simplified Chinese. Reply with the translation only.',
          },
        ],
        temperature: 0,
        max_tokens: 64,
        stream: false,
      }),
      signal: controller.signal,
    });

    const raw = await response.text();
    let data = null;
    try {
      data = JSON.parse(raw);
    } catch {
      /* 保持 raw */
    }

    if (!response.ok) {
      const message = data?.error?.message || data?.message || raw || `HTTP ${response.status}`;
      throw new Error(String(message).slice(0, 240));
    }

    const content = data?.choices?.[0]?.message?.content;
    if (!content || !String(content).trim()) {
      throw new Error('接口返回为空，请检查模型名称');
    }

    const elapsed = Math.round(performance.now() - startedAt);
    setTestResult(
      `连接成功 · ${elapsed} ms · 返回「${String(content).trim().slice(0, 24)}」`,
      'ok'
    );
  } catch (err) {
    if (err?.name === 'AbortError') {
      setTestResult('连接超时，请检查网络或接口地址', 'error');
    } else {
      setTestResult(`连接失败：${err.message}`, 'error');
    }
  } finally {
    clearTimeout(timeout);
    ui.testBtn.disabled = false;
  }
}

async function testBaidu(config) {
  if (!config.appId || !config.appSecret) {
    setTestResult('请填写百度 AppID 和密钥', 'error');
    return;
  }

  ui.testBtn.disabled = true;
  setTestResult('正在连接…', '');

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 25000);
  const startedAt = performance.now();

  try {
    const q = 'Hello';
    const salt = String(Date.now());
    const sign = md5(config.appId + q + salt + config.appSecret);
    const body = new URLSearchParams({
      q,
      from: 'en',
      to: 'zh',
      appid: config.appId,
      salt,
      sign,
    });

    const response = await fetch('https://fanyi-api.baidu.com/api/trans/vip/translate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body,
      signal: controller.signal,
    });

    const data = await response.json();

    if (data?.error_code) {
      throw new Error(baiduErrorText(data.error_code));
    }

    const content = data?.trans_result?.[0]?.dst;
    if (!content) throw new Error('接口返回为空');

    const elapsed = Math.round(performance.now() - startedAt);
    setTestResult(`连接成功 · ${elapsed} ms · 返回「${String(content).slice(0, 24)}」`, 'ok');
  } catch (err) {
    if (err?.name === 'AbortError') {
      setTestResult('连接超时，请检查网络', 'error');
    } else {
      setTestResult(`连接失败：${err.message}`, 'error');
    }
  } finally {
    clearTimeout(timeout);
    ui.testBtn.disabled = false;
  }
}

async function testMyMemory() {
  ui.testBtn.disabled = true;
  setTestResult('正在连接…', '');

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 25000);
  const startedAt = performance.now();

  try {
    const response = await fetch(
      'https://api.mymemory.translated.net/get?q=Hello&langpair=en%7Czh-CN',
      { signal: controller.signal }
    );
    const data = await response.json();

    if (Number(data?.responseStatus) !== 200) {
      throw new Error(data?.responseDetails || `HTTP ${data?.responseStatus}`);
    }

    const content = data?.responseData?.translatedText;
    if (!content) throw new Error('接口返回为空');

    const elapsed = Math.round(performance.now() - startedAt);
    setTestResult(`连接成功 · ${elapsed} ms · 返回「${String(content).slice(0, 24)}」`, 'ok');
  } catch (err) {
    if (err?.name === 'AbortError') {
      setTestResult('连接超时，请检查网络', 'error');
    } else {
      setTestResult(`连接失败：${err.message}`, 'error');
    }
  } finally {
    clearTimeout(timeout);
    ui.testBtn.disabled = false;
  }
}

function baiduErrorText(code) {
  const messages = {
    52001: '请求超时',
    52002: '系统错误',
    52003: 'AppID 无效或未授权',
    54000: '缺少必填参数',
    54001: '签名错误，请检查密钥',
    54003: '访问频率受限，请稍后重试',
    54004: '账户余额或免费额度不足',
    54005: '请求文本过长',
    58000: '客户端 IP 非法',
    58001: '语言方向不支持',
    58002: '服务已关闭',
  };
  return messages[code] || `百度翻译错误码 ${code}`;
}

function setTestResult(message, type) {
  ui.testResult.textContent = message;
  ui.testResult.classList.toggle('is-ok', type === 'ok');
  ui.testResult.classList.toggle('is-error', type === 'error');
}

function clearTestResult() {
  ui.testResult.textContent = '';
  ui.testResult.classList.remove('is-ok', 'is-error');
}

function showSaveState(message, isError = false) {
  ui.saveState.textContent = message;
  ui.saveState.classList.toggle('is-error', isError);
}

function isValidUrl(value) {
  try {
    const url = new URL(value);
    return url.protocol === 'https:' || url.protocol === 'http:';
  } catch {
    return false;
  }
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}
