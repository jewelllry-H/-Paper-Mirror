/**
 * 译镜 · 后台脚本
 * 点击工具栏图标时，把当前 PDF 链接交给扩展内的阅读器页面。
 */

const PDF_HINT = /\.pdf(?:[?#]|$)/i;

const MENU_LINK = 'open-pdf-link';
const MENU_PAGE = 'open-pdf-page';

chrome.runtime.onInstalled.addListener((details) => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: MENU_LINK,
      title: '用「译镜」翻译此 PDF',
      contexts: ['link'],
    });
    chrome.contextMenus.create({
      id: MENU_PAGE,
      title: '用「译镜」翻译当前页面中的 PDF',
      contexts: ['page'],
    });
  });

  if (details.reason === 'install') {
    chrome.tabs.create({ url: chrome.runtime.getURL('options.html?welcome=1') });
  }
});

chrome.action.onClicked.addListener(async (tab) => {
  const url = tab?.url || tab?.pendingUrl || '';

  if (!url || /^(edge|chrome|about|devtools|view-source):/i.test(url)) {
    openViewer('', '此页面无法读取。请先在浏览器中打开一个 PDF 文件，再点击插件图标。');
    return;
  }

  let target = url;
  if (!PDF_HINT.test(url)) {
    const embedded = await findEmbeddedPdf(tab.id);
    if (embedded) target = embedded;
  }

  openViewer(target);
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  const url = info.menuItemId === MENU_LINK ? info.linkUrl : (tab?.url || '');
  if (url) openViewer(url);
});

function openViewer(file, errorText) {
  const params = new URLSearchParams();
  if (file) params.set('file', file);
  if (errorText) params.set('error', errorText);
  chrome.tabs.create({
    url: `${chrome.runtime.getURL('viewer.html')}?${params.toString()}`,
  });
}

/**
 * 有些网站把 PDF 嵌在 iframe/embed 里，当前标签页地址并不是 .pdf。
 * 尽力从页面中找出真正的 PDF 地址。
 */
async function findEmbeddedPdf(tabId) {
  if (typeof tabId !== 'number') return '';

  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId, allFrames: true },
      func: () => {
        const direct = [...document.querySelectorAll('embed, iframe, object')]
          .map((el) => el.src || el.data || '')
          .filter(Boolean);

        const links = [...document.querySelectorAll('a[href]')]
          .map((a) => a.href)
          .filter((href) => /\.pdf(?:[?#]|$)/i.test(href))
          .slice(0, 8);

        return [...direct, ...links].find((u) => /\.pdf(?:[?#]|$)/i.test(u)) || '';
      },
    });

    for (const item of results || []) {
      if (item?.result) return item.result;
    }
  } catch (err) {
    console.warn('[译镜] 无法在当前页面查找嵌入的 PDF:', err);
  }

  return '';
}

async function updateBadge(tabId, url) {
  try {
    await chrome.action.setBadgeText({
      tabId,
      text: PDF_HINT.test(url || '') ? 'PDF' : '',
    });
    await chrome.action.setBadgeBackgroundColor({ tabId, color: '#2f6fed' });
  } catch {
    /* 标签页可能已关闭 */
  }
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.url || changeInfo.status === 'complete') {
    updateBadge(tabId, tab.url);
  }
});

chrome.tabs.onActivated.addListener(async ({ tabId }) => {
  try {
    const tab = await chrome.tabs.get(tabId);
    updateBadge(tabId, tab.url);
  } catch {
    /* ignore */
  }
});
