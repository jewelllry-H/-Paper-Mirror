﻿/**
 * 译镜 · 阅读器
 *
 * 思路：
 * 1. 用 PDF.js 把页面渲染到左侧 canvas；
 * 2. 从 PDF 中提取文字并按坐标合并成段落块；
 * 3. 把段落块交给兼容 OpenAI 的翻译接口；
 * 4. 在右侧同尺寸的「纸面」上按原坐标重排译文。
 */

import * as pdfjsLib from './lib/pdf.min.mjs';
import Tesseract from './lib/tesseract/tesseract.esm.min.js';
import md5 from './lib/md5.js';
import { DEFAULT_SETTINGS, normalizeBaseUrl } from './config.js';

pdfjsLib.GlobalWorkerOptions.workerPort = new Worker(
  new URL('./lib/pdf.worker.min.mjs', import.meta.url),
  { type: 'module' }
);

const IMAGE_OP_IDS = new Set(
  Object.entries(pdfjsLib.OPS)
    .filter(([name]) => name.startsWith('paintImage') || name.startsWith('paintJpeg'))
    .map(([, id]) => id)
);

const $ = (id) => document.getElementById(id);

const ui = {
  docTitle: $('docTitle'),
  docSub: $('docSub'),
  pages: $('pages'),
  viewport: $('viewport'),
  pagePrev: $('pagePrev'),
  pageNext: $('pageNext'),
  pageInput: $('pageInput'),
  pageTotal: $('pageTotal'),
  viewButtons: [...document.querySelectorAll('.view-switch button')],
  zoomOut: $('zoomOut'),
  zoomIn: $('zoomIn'),
  zoomLabel: $('zoomLabel'),
  translateBtn: $('translateBtn'),
  translateLabel: $('translateLabel'),
  translateSpinner: $('translateSpinner'),
  settingsBtn: $('settingsBtn'),
  setupBanner: $('setupBanner'),
  setupAction: $('setupAction'),
  notice: $('notice'),
  noticeIcon: $('noticeIcon'),
  noticeText: $('noticeText'),
  noticeActions: $('noticeActions'),
  noticeClose: $('noticeClose'),
  loadingLayer: $('loadingLayer'),
  loadingText: $('loadingText'),
  loadingBar: $('loadingBar'),
  loadingHint: $('loadingHint'),
  errorLayer: $('errorLayer'),
  errorTitle: $('errorTitle'),
  errorText: $('errorText'),
  errorActions: $('errorActions'),
  hoverTip: $('hoverTip'),
  toast: $('toast'),
  progressLine: $('progressLine'),
  transBadge: $('transBadge'),
};

const state = {
  settings: { ...DEFAULT_SETTINGS },
  pdf: null,
  url: '',
  pages: [],
  paneW: 0,
  zoom: clamp(readNumber('pr.zoom', 1), 0.5, 2.5),
  viewMode: readViewMode(),
  translating: false,
  translationStarted: false,
  abort: null,
  fatalError: null,
  observer: null,
  currentPage: 1,
  toastTimer: 0,
  scrollTick: false,
  referencesStart: null,
};

const translationCache = new Map();
const CACHE_NAME = 'pr_translation_cache_v1';
const OCR_CACHE_NAME = 'pr_ocr_cache_v1';

let ocrWorkerPromise = null;
const ocrGate = createGate(1);

let baiduNextRequestAt = 0;
const baiduGate = createGate(1);
let myMemoryNextRequestAt = 0;
const myMemoryGate = createGate(1);

/* ============================ 启动 ============================ */

init().catch((err) => {
  console.error('[译镜] 初始化失败', err);
  showError('初始化失败', err?.message || String(err), [
    { label: '重新加载', primary: true, onClick: () => location.reload() },
  ]);
});

async function init() {
  loadCache();
  await loadSettings();

  bindUi();
  applyViewMode(state.viewMode, false);
  updateZoomLabel();
  ui.transBadge.textContent = state.settings.targetLang;
  updateTranslateButton();

  const params = new URLSearchParams(location.search);
  const explicitError = params.get('error');

  if (explicitError) {
    showError('无法打开页面', explicitError, [
      { label: '返回上一页', onClick: () => history.back() },
      { label: '打开设置', onClick: openOptions },
    ]);
    return;
  }

  const file = params.get('file');
  if (!file) {
    showError(
      '没有 PDF 地址',
      '请先直接在浏览器中打开 PDF，再点击工具栏上的「译镜」图标；也可以右键点击 PDF 链接，选择「用译镜翻译此 PDF」。',
      [{ label: '打开设置', onClick: openOptions }]
    );
    return;
  }

  state.url = file;

  try {
    await openDocument(file);
  } catch (err) {
    handleOpenError(err);
    return;
  }

  if (!hasTranslationConfig()) {
    showSetupBanner(true);
  } else if (state.settings.autoTranslate) {
    startTranslation();
  }
}

function hasTranslationConfig() {
  const settings = state.settings;
  if (settings.provider === 'mymemory') return true;
  if (settings.provider === 'baidu') return Boolean(settings.appId && settings.appSecret);
  return Boolean(settings.apiKey);
}

/* ============================ 设置 ============================ */

async function loadSettings() {
  const stored = await chrome.storage.local.get(DEFAULT_SETTINGS);
  state.settings = { ...DEFAULT_SETTINGS, ...stored };
  state.settings.concurrency = clamp(Number(state.settings.concurrency) || 2, 1, 4);
  state.settings.batchChars = clamp(Number(state.settings.batchChars) || 1600, 500, 4000);
  state.settings.fontScale = clamp(Number(state.settings.fontScale) || 1, 0.8, 1.2);
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  const keys = [
    'apiKey', 'appId', 'appSecret', 'baseUrl', 'model', 'provider', 'targetLang',
    'autoTranslate', 'concurrency', 'batchChars', 'fontScale', 'keepGraphics',
    'translateReferences', 'ocrFigures',
  ];
  if (!keys.some((key) => key in changes)) return;

  const hadKey = hasTranslationConfig();
  const previousLang = state.settings.targetLang;

  loadSettings().then(() => {
    ui.transBadge.textContent = state.settings.targetLang;
    showSetupBanner(!hasTranslationConfig());

    if (!state.settings.keepGraphics) {
      for (const p of state.pages) clearGhost(p);
    }

    if (previousLang !== state.settings.targetLang && state.pages.length) {
      const wasTranslating = state.translating;
      if (wasTranslating) stopTranslation();

      for (const p of state.pages) {
        p.translations.clear();
        p.hasTranslation = false;
        p.status = 'idle';
        p.done = false;
        p.error = null;
        p.transVersion += 1;
        p.renderedVersion = -1;
        p.blocksRendered = false;
        p.tblocks.textContent = '';
        clearGhost(p);
        updatePageStatus(p);
      }

      updateTranslateButton();

      if (wasTranslating) {
        showNotice('目标语言已切换，请重新点击「翻译全文」。');
      } else if (hasTranslationConfig() && state.settings.autoTranslate) {
        startTranslation();
      }
      return;
    }

    if (hasTranslationConfig() && !hadKey && state.pdf && state.settings.autoTranslate && !state.translationStarted) {
      startTranslation();
    }

    for (const p of state.pages) p.renderedVersion = -1;
    refreshVisiblePages();

    if ('translateReferences' in changes || 'ocrFigures' in changes) {
      showNotice('参考文献 / OCR 设置已更新，重新打开文献后生效。');
    }
  });
});

/* ============================ 打开 PDF ============================ */

async function openDocument(url) {
  ui.loadingLayer.hidden = false;
  setLoading('正在下载 PDF…', 0.02, hostLabel(url));

  const bytes = await fetchPdfBytes(url, (loaded, total) => {
    const ratio = total ? 0.02 + 0.16 * (loaded / total) : Math.min(0.18, 0.02 + loaded / (6 * 1024 * 1024));
    setLoading(
      '正在下载 PDF…',
      ratio,
      total
        ? `${formatBytes(loaded)} / ${formatBytes(total)}`
        : `${formatBytes(loaded)}`
    );
  });

  const header = new TextDecoder('latin1').decode(bytes.slice(0, 1024));
  if (!header.includes('%PDF-')) {
    throw Object.assign(new Error('返回的内容不是 PDF 文件。'), { kind: 'notpdf' });
  }

  setLoading('正在解析文档…', 0.22);

  const task = pdfjsLib.getDocument({
    data: bytes,
    cMapUrl: chrome.runtime.getURL('cmaps/'),
    cMapPacked: true,
    standardFontDataUrl: chrome.runtime.getURL('standard_fonts/'),
  });

  task.onProgress = ({ loaded, total }) => {
    if (total) {
      setLoading('正在解析文档…', 0.22 + 0.12 * (loaded / total), formatBytes(loaded));
    }
  };

  let pdf;
  try {
    pdf = await task.promise;
  } catch (err) {
    throw Object.assign(err, { kind: 'parse' });
  }

  state.pdf = pdf;

  let title = '';
  let author = '';
  try {
    const meta = await pdf.getMetadata();
    title = String(meta?.info?.Title || '').trim();
    author = String(meta?.info?.Author || '').trim();
  } catch {
    /* 没元数据也没关系 */
  }

  title = cleanTitle(title);
  if (!title || /^(untitled|无标题|unknown)$/i.test(title)) {
    title = cleanTitle(fileNameFromUrl(url)) || '未命名文献';
  }

  ui.docTitle.textContent = title;
  ui.docTitle.title = author ? `${title} · ${author}` : title;
  document.title = `${title} · 译镜`;

  const host = hostLabel(url);
  ui.docSub.textContent = `${pdf.numPages} 页 · ${host}${author ? ` · ${author}` : ''}`;
  ui.pageTotal.textContent = String(pdf.numPages);
  ui.pageInput.max = String(pdf.numPages);

  setLoading('正在读取页面…', 0.36);

  let loadedPages = 0;
  const pageNumbers = Array.from({ length: pdf.numPages }, (_, i) => i + 1);

  const pages = await mapLimit(pageNumbers, 4, async (n) => {
    const page = await pdf.getPage(n);
    const viewport = page.getViewport({ scale: 1 });

    loadedPages += 1;
    setLoading(
      '正在读取页面…',
      0.36 + 0.52 * (loadedPages / pdf.numPages),
      `第 ${loadedPages} / ${pdf.numPages} 页`
    );

    return {
      n,
      page,
      pageW: viewport.width,
      pageH: viewport.height,
      scale: 1,
      sheetW: 0,
      sheetH: 0,
      row: null,
      model: null,
      modelPromise: null,
      translations: new Map(),
      hasTranslation: false,
      status: 'idle', // idle | queued | translating | ocr | done | error
      error: null,
      ocrDone: false,
      ocrPromise: null,
      hasImages: undefined,
      referencesOnly: false,
      referenceFiltered: false,
      done: false,
      transVersion: 0,
      renderedVersion: -1,
      blocksRendered: false,
      renderedScale: 0,
      canvasRendered: false,
      renderedCanvasScale: 0,
      rendering: false,
      renderAgain: false,
      ghost: null,
      ghostReady: false,
      ghostRendering: false,
      ghostAgain: false,
      ghostVersion: -1,
      ghostScale: 0,
      layoutDirty: true,
      statusEl: null,
      statusText: null,
      hitEls: new Map(),
      blockEls: new Map(),
    };
  });

  state.pages = pages;
  state.referencesStart = null;

  if (!state.settings.translateReferences) {
    setLoading('正在分析文档结构…', 0.9, '查找参考文献…');
    await detectReferences(pages);
  }

  buildPageDom();
  applyLayout();
  observePages();
  updatePageIndicator(1);

  document.body.classList.remove('is-loading');
  ui.loadingLayer.hidden = true;
  updateTranslateButton();
}

async function fetchPdfBytes(url, onProgress) {
  let response;
  try {
    response = await fetch(url, { credentials: 'include' });
  } catch (err) {
    throw Object.assign(new Error(err?.message || '网络请求失败'), { kind: 'network' });
  }

  if (!response.ok) {
    throw Object.assign(new Error(`下载失败（HTTP ${response.status}）`), {
      kind: 'http',
      status: response.status,
    });
  }

  const total = Number(response.headers.get('content-length')) || 0;

  if (!response.body) {
    const buffer = new Uint8Array(await response.arrayBuffer());
    onProgress?.(buffer.length, total || buffer.length);
    return buffer;
  }

  const reader = response.body.getReader();
  const chunks = [];
  let loaded = 0;

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    chunks.push(value);
    loaded += value.length;
    onProgress?.(loaded, total);
  }

  const bytes = new Uint8Array(loaded);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.length;
  }
  return bytes;
}

/**
 * 查找参考文献标题。找到后记录页号和 y 坐标，
 * 之后的块可以跳过翻译（用户可在设置里关闭此行为）。
 */
async function detectReferences(pages) {
  const pattern =
    /^(?:\d+(?:\.\d+)*[.)]?\s*)?(references|bibliography|works cited|literature cited|参考文献)\s*[:：]?$/i;

  for (const p of pages) {
    let textContent;
    try {
      textContent = await p.page.getTextContent();
    } catch {
      continue;
    }

    const viewport = p.page.getViewport({ scale: 1 });
    for (const item of textContent.items || []) {
      const text = String(item?.str || '').replace(/\s+/g, ' ').trim();
      if (!text || !pattern.test(text)) continue;

      const transform = pdfjsLib.Util.transform(viewport.transform, item.transform);
      const baseline = transform[5];
      if (!Number.isFinite(baseline) || baseline < p.pageH * 0.03) continue;

      state.referencesStart = { page: p.n, y: baseline - 2 };
      return;
    }
  }
}

function isReferenceHeading(text) {
  return /^(?:\d+(?:\.\d+)*[.)]?\s*)?(references|bibliography|works cited|literature cited|参考文献)\s*[:：]?$/i.test(
    String(text || '').trim()
  );
}

/**
 * 去掉参考文献部分，避免把整段参考文献送进翻译接口。
 * 标题本身保留翻译；标题之前的正文保留。
 */
function applyReferenceFilter(p) {
  if (p.referenceFiltered) return;
  p.referenceFiltered = true;

  if (state.settings.translateReferences) return;

  const start = state.referencesStart;
  if (!start || p.n < start.page) return;

  const before = p.model.blocks.length;

  p.model.blocks = p.model.blocks.filter((block) => {
    if (p.n > start.page) return false;
    if (block.y + block.h <= start.y) return true;
    return isReferenceHeading(block.text);
  });

  if (before > 0 && p.model.blocks.length === 0) {
    p.referencesOnly = true;
  }

  p.layoutDirty = true;
  p.renderedVersion = -1;
}

/* ============================ 图表 OCR ============================ */

async function pageHasImages(p) {
  if (typeof p.hasImages === 'boolean') return p.hasImages;

  try {
    const operatorList = await p.page.getOperatorList();
    p.hasImages = operatorList.fnArray.some((fn) => IMAGE_OP_IDS.has(fn));
  } catch {
    p.hasImages = false;
  }

  return p.hasImages;
}

function getOcrWorker() {
  if (!ocrWorkerPromise) {
    ocrWorkerPromise = Tesseract.createWorker('eng', 1, {
      workerPath: chrome.runtime.getURL('lib/tesseract/worker.min.js'),
      corePath: chrome.runtime.getURL('lib/tesseract/tesseract-core-simd-lstm.wasm.js'),
      langPath: chrome.runtime.getURL('tessdata'),
      workerBlobURL: false,
      gzip: true,
      errorHandler: (error) => console.warn('[译镜] OCR worker 错误', error),
    })
      .then(async (worker) => {
        await worker.setParameters({
          tessedit_pageseg_mode: Tesseract.PSM.SPARSE_TEXT,
          preserve_interword_spaces: '1',
          user_defined_dpi: '150',
        });
        return worker;
      })
      .catch((err) => {
        ocrWorkerPromise = null;
        throw err;
      });
  }

  return ocrWorkerPromise;
}

async function ensureOcr(p) {
  if (!state.settings.ocrFigures) return;
  if (p.ocrDone) return;
  if (p.ocrPromise) return p.ocrPromise;

  p.ocrPromise = (async () => {
    try {
      if (!(await pageHasImages(p))) {
        p.ocrDone = true;
        return;
      }

      let labels = readOcrCache(p);

      if (!labels) {
        await ocrGate.acquire();
        try {
          labels = await ocrPage(p);
          writeOcrCache(p, labels);
        } finally {
          ocrGate.release();
        }
      }

      appendOcrLabels(p, labels || []);
      p.ocrDone = true;
      p.layoutDirty = true;
      p.renderedVersion = -1;
    } catch (err) {
      console.warn('[译镜] 图表 OCR 失败', p.n, err);
      p.ocrDone = true;
    } finally {
      p.ocrPromise = null;
    }
  })();

  return p.ocrPromise;
}

async function ocrPage(p) {
  const scale = 3.5;
  const viewport = p.page.getViewport({ scale });
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, Math.round(viewport.width));
  canvas.height = Math.max(1, Math.round(viewport.height));

  const context = canvas.getContext('2d', {
    alpha: false,
    willReadFrequently: true,
  });

  context.fillStyle = '#ffffff';
  context.fillRect(0, 0, canvas.width, canvas.height);

  const renderTask = p.page.render({ canvasContext: context, viewport });
  await renderTask.promise;

  // 把 PDF 文本层全部抹白，OCR 只关注图片/矢量轮廓里的文字
  context.fillStyle = '#ffffff';
  const pad = 1.5;
  for (const rect of p.model.textRects || []) {
    context.fillRect(
      (rect.x - pad) * scale,
      (rect.y - pad) * scale,
      (rect.w + pad * 2) * scale,
      (rect.h + pad * 2) * scale
    );
  }

  // 灰度 + 二值化，Tesseract 对彩色图表的识别率更高
  const image = context.getImageData(0, 0, canvas.width, canvas.height);
  const pixels = image.data;

  for (let i = 0; i < pixels.length; i += 4) {
    const lum = 0.299 * pixels[i] + 0.587 * pixels[i + 1] + 0.114 * pixels[i + 2];
    const value = lum < 150 ? 0 : 255;
    pixels[i] = value;
    pixels[i + 1] = value;
    pixels[i + 2] = value;
  }

  context.putImageData(image, 0, 0);

  const worker = await getOcrWorker();
  const result = await worker.recognize(canvas, {}, { blocks: true });

  return extractOcrLabels(p, result.data, scale);
}

function extractOcrLabels(p, data, scale) {
  const textRects = p.model.textRects || [];
  const blocks = p.model.blocks;
  const candidates = [];

  for (const block of data.blocks || []) {
    for (const paragraph of block.paragraphs || []) {
      for (const line of paragraph.lines || []) {
        const rawText = String(line.text || '').trim();
        let text = rawText.replace(/\s+/g, ' ').trim();

        if (!text) continue;
        if (line.confidence < 60) continue;
        if (text.length < 2 || text.length > 110) continue;

        // OCR 经常把边框/箭头识别成带括号的碎片
        if (/^[\s\[\]{}|<>_=+~`^\\/]/.test(rawText)) continue;
        if (/[\s\[\]{}|<>_=+~`^\\/]$/.test(rawText)) continue;

        const letters = (text.match(/[A-Za-z]/g) || []).length;
        if (letters < 2) continue;

        const mathSymbols = (text.match(/[=<>√∑∫±×÷≤≥≈∞∂∇μπθλ]/g) || []).length;
        if (mathSymbols >= 2 && letters < 8) continue;

        const bbox = line.bbox;
        if (!bbox) continue;

        const x = bbox.x0 / scale;
        const y = bbox.y0 / scale;
        const w = (bbox.x1 - bbox.x0) / scale;
        const h = (bbox.y1 - bbox.y0) / scale;

        if (w < 6 || h < 4) continue;

        const centerX = x + w / 2;
        const centerY = y + h / 2;

        // OCR 结果如果落在 PDF 文字层里，说明是没盖干净的重复内容
        const overlapsText = textRects.some(
          (rect) =>
            centerX >= rect.x - 1 &&
            centerX <= rect.x + rect.w + 1 &&
            centerY >= rect.y - 1 &&
            centerY <= rect.y + rect.h + 1
        );
        if (overlapsText) continue;

        const overlapsBlock = blocks.some(
          (blockItem) =>
            centerX >= blockItem.x - 1 &&
            centerX <= blockItem.x + blockItem.w + 1 &&
            centerY >= blockItem.y - 1 &&
            centerY <= blockItem.y + blockItem.h + 1
        );
        if (overlapsBlock) continue;

        candidates.push({ text, x, y, w, h, confidence: line.confidence });
      }
    }
  }

  candidates.sort((a, b) => b.confidence - a.confidence || b.w * b.h - a.w * a.h);

  const labels = [];

  for (const candidate of candidates) {
    if (labels.length >= 80) break;

    const duplicate = labels.some((label) => {
      if (
        label.text.toLowerCase() === candidate.text.toLowerCase() &&
        Math.abs(label.x - candidate.x) < 5 &&
        Math.abs(label.y - candidate.y) < 5
      ) {
        return true;
      }

      const overlapW =
        Math.min(label.x + label.w, candidate.x + candidate.w) -
        Math.max(label.x, candidate.x);
      const overlapH =
        Math.min(label.y + label.h, candidate.y + candidate.h) -
        Math.max(label.y, candidate.y);

      if (overlapW <= 0 || overlapH <= 0) return false;

      return (
        overlapW * overlapH >
        Math.min(label.w * label.h, candidate.w * candidate.h) * 0.45
      );
    });

    if (!duplicate) labels.push(candidate);
  }

  labels.sort((a, b) => a.y - b.y || a.x - b.x);
  return labels;
}

function appendOcrLabels(p, labels) {
  if (!labels.length) return;

  const existing = p.model.blocks;

  labels.forEach((label, index) => {
    const width = Math.max(4, label.w);
    const height = Math.max(4, label.h);
    const fontSize = clamp(height * 0.95, 4, 24);

    existing.push({
      id: `${p.n}:ocr:${index}`,
      x: label.x,
      y: label.y,
      top: label.y,
      right: label.x + width,
      bottom: label.y + height,
      w: width,
      h: height,
      growH: height,
      fontSize,
      text: label.text,
      lines: [{ text: label.text, bold: false }],
      bold: false,
      align: 'center',
      isLabel: true,
      source: 'ocr',
    });
  });

  p.layoutDirty = true;
  p.renderedVersion = -1;
}

function readOcrCache(p) {
  try {
    const raw = JSON.parse(localStorage.getItem(OCR_CACHE_NAME) || '{}');
    const entry = raw[`${state.url}::${p.n}`];
    if (!entry || entry.v !== 3 || !Array.isArray(entry.labels)) return null;
    return entry.labels;
  } catch {
    return null;
  }
}

function writeOcrCache(p, labels) {
  try {
    const raw = JSON.parse(localStorage.getItem(OCR_CACHE_NAME) || '{}');
    raw[`${state.url}::${p.n}`] = { v: 3, labels };
    const keys = Object.keys(raw);
    if (keys.length > 300) {
      for (const key of keys.slice(0, keys.length - 300)) delete raw[key];
    }
    localStorage.setItem(OCR_CACHE_NAME, JSON.stringify(raw));
  } catch {
    /* 缓存失败不影响翻译 */
  }
}

function handleOpenError(err) {
  console.error('[译镜] 打开 PDF 失败', err);

  let title = '无法打开这篇文献';
  let message = err?.message || String(err);

  if (err?.kind === 'notpdf') {
    title = '这里不是 PDF';
    message =
      '当前地址返回的不是 PDF 文件。如果 PDF 是嵌在网页里的，请先在新标签页中打开它，或右键点击 PDF 链接，选择「用译镜翻译此 PDF」。';
  } else if (err?.kind === 'http') {
    if (err.status === 401 || err.status === 403) {
      title = '没有访问权限';
      message = `站点拒绝了下载请求（HTTP ${err.status}）。这篇文献可能需要登录，或有防爬限制。可以先把 PDF 下载到本地，再在浏览器中打开本地文件。`;
    } else if (err.status === 404) {
      title = '文件不存在';
      message = '链接可能已经失效（HTTP 404），请检查地址是否正确。';
    }
  } else if (err?.kind === 'network' && state.url.startsWith('file:')) {
    message =
      '无法读取本地文件。请在扩展管理页（edge://extensions 或 chrome://extensions）中开启本扩展的「允许访问文件网址 / 允许访问文件 URL」，然后重新打开。';
  } else if (err?.name === 'PasswordException') {
    title = 'PDF 已加密';
    message = '这篇 PDF 受密码保护，暂时无法读取其中的文字。';
  } else if (err?.name === 'InvalidPDFException') {
    title = 'PDF 解析失败';
    message = 'PDF 文件可能损坏，或使用了暂不支持的格式。';
  }

  const actions = [
    { label: '重试', primary: true, onClick: () => location.reload() },
    {
      label: '在新标签页打开原文件',
      onClick: () => chrome.tabs.create({ url: state.url.startsWith('file:') ? state.url : state.url }),
    },
  ];

  showError(title, message, actions);
}

/* ============================ 页面 DOM / 布局 ============================ */

function buildPageDom() {
  const fragment = document.createDocumentFragment();

  for (const p of state.pages) {
    const row = document.createElement('section');
    row.className = 'page-row';
    row.dataset.page = String(p.n);

    row.innerHTML = `
      <div class="pane original">
        <div class="sheet sheet-original">
          <canvas></canvas>
          <div class="hits"></div>
        </div>
      </div>
      <div class="pane translated">
        <div class="sheet sheet-translated">
          <canvas class="ghost-canvas"></canvas>
          <div class="page-status" hidden>
            <span class="spinner"></span>
            <span class="status-text">等待翻译</span>
          </div>
          <div class="tblocks"></div>
        </div>
      </div>
    `;

    p.row = row;
    p.origSheet = row.querySelector('.sheet-original');
    p.transSheet = row.querySelector('.sheet-translated');
    p.canvas = row.querySelector('.sheet-original canvas');
    p.ghost = row.querySelector('.ghost-canvas');
    p.hits = row.querySelector('.hits');
    p.tblocks = row.querySelector('.tblocks');
    p.statusEl = row.querySelector('.page-status');
    p.statusText = row.querySelector('.status-text');

    p.statusEl.addEventListener('click', () => {
      if (p.status === 'error' && !state.translating) retryPage(p);
    });

    bindPageHover(p);
    row.__page = p;
    fragment.appendChild(row);
  }

  ui.pages.appendChild(fragment);
}

function applyLayout() {
  if (!state.pages.length) return;
  if (!state.pages[0].origSheet) return; // 页面 DOM 还没建好（例如正在分析文档结构）

  const cols = state.viewMode === 'dual' ? 2 : 1;
  const viewportWidth = ui.viewport.clientWidth;
  const horizontalPadding = viewportWidth < 900 ? 28 : 48;
  const available = Math.max(300, viewportWidth - horizontalPadding);
  const gap = 24;
  const basePane = (available - gap * (cols - 1)) / cols;
  const paneW = clamp(basePane * state.zoom, 220, 2600);
  const scaleChanged = Math.abs(paneW - state.paneW) > 0.5;

  state.paneW = paneW;
  ui.pages.style.setProperty('--cols', String(cols));
  ui.pages.style.setProperty('--pane-w', `${paneW}px`);

  for (const p of state.pages) {
    const scale = paneW / p.pageW;
    p.scale = scale;
    p.sheetW = paneW;
    p.sheetH = p.pageH * scale;

    p.origSheet.style.width = `${p.sheetW}px`;
    p.origSheet.style.height = `${p.sheetH}px`;
    p.transSheet.style.width = `${p.sheetW}px`;
    p.transSheet.style.height = `${p.sheetH}px`;
    p.canvas.style.width = `${p.sheetW}px`;
    p.canvas.style.height = `${p.sheetH}px`;

    if (scaleChanged) {
      p.renderedVersion = -1;
      p.blocksRendered = false;
      p.layoutDirty = true;

      if (nearViewport(p)) {
        if (state.viewMode !== 'translated') renderCanvas(p);
        if (p.model) layoutPage(p);
      }
    }
  }

  updateZoomLabel();
  refreshVisiblePages();
}

function setZoom(nextZoom) {
  state.zoom = clamp(nextZoom, 0.5, 2.5);
  localStorage.setItem('pr.zoom', String(state.zoom));
  applyLayout();
}

function updateZoomLabel() {
  ui.zoomLabel.textContent = `${Math.round(state.zoom * 100)}%`;
}

function applyViewMode(mode, relayout = true) {
  if (!['dual', 'original', 'translated'].includes(mode)) mode = 'dual';
  state.viewMode = mode;
  document.body.classList.remove('mode-dual', 'mode-original', 'mode-translated');
  document.body.classList.add(`mode-${mode}`);
  for (const button of ui.viewButtons) {
    button.classList.toggle('is-active', button.dataset.view === mode);
  }
  localStorage.setItem('pr.view', mode);

  if (relayout && state.pages.length) {
    applyLayout();
    for (const p of state.pages) {
      if (nearViewport(p)) {
        if (mode !== 'translated') renderCanvas(p);
        if (p.model && p.layoutDirty) layoutPage(p);
        if (mode !== 'original' && p.hasTranslation) renderTranslation(p, true);
      }
    }
  }
}

function observePages() {
  state.observer?.disconnect();

  state.observer = new IntersectionObserver(
    (entries) => {
      for (const entry of entries) {
        const p = entry.target.__page;
        if (!p) continue;

        if (entry.isIntersecting) {
          ensureModel(p)
            .then(() => {
              if (p.layoutDirty) layoutPage(p);
              if (p.hasTranslation) renderTranslation(p);
            })
            .catch((err) => console.warn('[译镜] 提取文字失败', p.n, err));

          if (state.viewMode !== 'translated') renderCanvas(p);
        } else if (!nearViewport(p, 1400)) {
          // 离得远的页面释放位图，控制内存
          if (p.canvasRendered) {
            p.canvas.width = 0;
            p.canvas.height = 0;
            p.canvasRendered = false;
          }
          if (p.ghostReady) clearGhost(p);
        }
      }
    },
    { root: ui.viewport, rootMargin: '900px 0px' }
  );

  for (const p of state.pages) state.observer.observe(p.row);

  if (!observePages.bound) {
    observePages.bound = true;
    ui.viewport.addEventListener('scroll', onViewportScroll, { passive: true });
  }
}

function nearViewport(p, margin = 1000) {
  if (!p?.row) return false;
  const rect = p.row.getBoundingClientRect();
  const viewportRect = ui.viewport.getBoundingClientRect();
  return rect.bottom > viewportRect.top - margin && rect.top < viewportRect.bottom + margin;
}

function refreshVisiblePages() {
  for (const p of state.pages) {
    if (!nearViewport(p)) continue;
    if (state.viewMode !== 'translated') renderCanvas(p);
    if (p.layoutDirty && p.model) layoutPage(p);
    if (state.viewMode !== 'original' && p.hasTranslation) renderTranslation(p, true);
  }
}

/* ============================ 画布渲染 ============================ */

const renderGate = createGate(2);

async function renderCanvas(p) {
  if (!p || !p.page || state.viewMode === 'translated') return;
  if (p.rendering) {
    p.renderAgain = true;
    return;
  }
  if (p.canvasRendered && Math.abs(p.renderedCanvasScale - p.scale) < 0.0005) return;

  p.rendering = true;

  try {
    await renderGate.acquire();

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const viewport = p.page.getViewport({ scale: p.scale * dpr });
    const canvas = p.canvas;

    canvas.width = Math.max(1, Math.round(viewport.width));
    canvas.height = Math.max(1, Math.round(viewport.height));
    p.canvasRendered = false; // 画布已清空，正在重绘

    const context = canvas.getContext('2d', { alpha: false });
    context.save();
    context.fillStyle = '#ffffff';
    context.fillRect(0, 0, canvas.width, canvas.height);
    context.restore();

    const task = p.page.render({ canvasContext: context, viewport });
    try {
      await task.promise;
    } catch (err) {
      if (err?.name !== 'RenderingCancelledException') throw err;
    }

    p.canvasRendered = true;
    p.renderedCanvasScale = p.scale;

    if (p.hasTranslation) scheduleGhost(p);
  } catch (err) {
    console.warn('[译镜] 页面渲染失败', p.n, err);
  } finally {
    p.rendering = false;
    renderGate.release();

    if (p.renderAgain) {
      p.renderAgain = false;
      if (nearViewport(p)) renderCanvas(p);
    }
  }
}

/* ============================ 文本提取 / 版式分析 ============================ */

async function ensureModel(p) {
  if (p.model) return p.model;
  if (p.modelPromise) return p.modelPromise;

  p.modelPromise = (async () => {
    const textContent = await p.page.getTextContent();
    p.model = buildPageModel(p, textContent);
    p.layoutDirty = true;
    return p.model;
  })().catch((err) => {
    p.modelPromise = null;
    throw err;
  });

  return p.modelPromise;
}

function buildPageModel(p, textContent) {
  const viewport = p.page.getViewport({ scale: 1 });
  const items = [];
  const textRects = [];

  for (const raw of textContent.items || []) {
    if (!raw || typeof raw.str !== 'string') continue;
    if (!raw.str.trim()) continue;
    if (!Number.isFinite(raw.width) || raw.width <= 0) continue;

    const transform = pdfjsLib.Util.transform(viewport.transform, raw.transform);
    if (Math.abs(transform[1]) > 0.8 || Math.abs(transform[2]) > 0.8) continue;

    const fontH = Math.hypot(transform[2], transform[3]) || raw.height || 10;
    const x = transform[4];
    const baseline = transform[5];

    if (!Number.isFinite(x) || !Number.isFinite(baseline)) continue;

    const top = baseline - fontH * 0.8;
    items.push({
      x,
      top,
      baseline,
      w: raw.width,
      fontH,
      str: raw.str,
      bold: /(bold|black|heavy|semibold|demi)/i.test(raw.fontName || ''),
    });
    textRects.push({ x, y: top, w: raw.width, h: fontH * 1.05 });
  }

  if (!items.length) return { blocks: [], textRects: [] };

  // 1) 按基线聚成行
  items.sort((a, b) => a.baseline - b.baseline || a.x - b.x);
  const lines = [];

  for (const item of items) {
    const tolerance = Math.max(1.8, item.fontH * 0.32);
    let line = null;

    for (let i = lines.length - 1, checked = 0; i >= 0 && checked < 8; i -= 1, checked += 1) {
      if (Math.abs(lines[i].baseline - item.baseline) <= tolerance) {
        line = lines[i];
        break;
      }
    }

    if (!line) {
      line = { baseline: item.baseline, items: [] };
      lines.push(line);
    }
    line.items.push(item);
  }

  // 2) 行内按横向间距切成片段（避免把表格不同列粘在一起）
  for (const line of lines) line.items.sort((a, b) => a.x - b.x);

  // 双栏论文的栏间距常常不到 1.4 个字宽，需要单独识别并强制在栏缝处切开
  const columnSplit = detectColumnSplit(items, p.pageW, p.pageH);
  const segments = [];

  for (const line of lines) {
    let segment = null;

    for (const item of line.items) {
      if (!segment) {
        segment = { items: [item] };
        continue;
      }

      const previous = segment.items[segment.items.length - 1];
      const previousRight = previous.x + previous.w;
      const gap = item.x - previousRight;

      const crossesGutter =
        columnSplit > 0 &&
        previousRight < columnSplit - 0.5 &&
        item.x > columnSplit + 0.5;
      const hasGutterGap = crossesGutter && gap > Math.max(3, item.fontH * 0.5);

      if (gap > Math.max(6, item.fontH * 1.4) || hasGutterGap) {
        segments.push(finalizeSegment(segment));
        segment = { items: [item] };
      } else {
        segment.items.push(item);
      }
    }

    if (segment) segments.push(finalizeSegment(segment));
  }

  // 3) 把相邻行合并成段落
  segments.sort((a, b) => a.top - b.top || a.x - b.x);
  const blocks = [];

  for (const segment of segments) {
    let best = null;
    let bestScore = Infinity;

    for (const block of blocks) {
      const last = block.lines[block.lines.length - 1];
      const lineHeight = Math.max(block.fontSize, segment.fontSize);
      const gap = segment.top - last.bottom;
      const overlap = Math.min(last.right, segment.right) - Math.max(last.x, segment.x);
      const overlapRatio = overlap / Math.max(1, Math.min(last.w, segment.w));
      const sizeRatio = segment.fontSize / block.fontSize;

      if (overlapRatio < 0.45) continue;
      if (gap < -lineHeight * 0.8 || gap > lineHeight * 0.85) continue;
      if (sizeRatio < 0.78 || sizeRatio > 1.28) continue;

      const pageCenter = p.pageW / 2;
      const lastCenter = (last.x + last.right) / 2;
      const segmentCenter = (segment.x + segment.right) / 2;
      const bothCentered =
        Math.abs(lastCenter - pageCenter) < p.pageW * 0.06 &&
        Math.abs(segmentCenter - pageCenter) < p.pageW * 0.06;

      // 首行缩进 → 新段落（居中的标题行除外）
      if (!bothCentered && segment.x - last.x > Math.max(3, block.fontSize * 0.75)) continue;
      if (block.text.length > 1400 || block.lines.length >= 36) continue;

      // 不要把单栏段落并入横跨整页的块（例如摘要、跨栏标题）
      if (block.w > p.pageW * 0.7 && segment.w < p.pageW * 0.45) continue;

      const score = Math.abs(gap) + (1 - overlapRatio) * 8 + Math.abs(1 - sizeRatio) * 4;
      if (score < bestScore) {
        bestScore = score;
        best = block;
      }
    }

    if (best) {
      best.lines.push(segment);
      best.x = Math.min(best.x, segment.x);
      best.right = Math.max(best.right, segment.right);
      best.top = Math.min(best.top, segment.top);
      best.bottom = Math.max(best.bottom, segment.bottom);
      best.w = best.right - best.x;
      best.h = best.bottom - best.top;
      best.text = joinTexts(best.text, segment.text);
      best.fontSize =
        (best.fontSize * (best.lines.length - 1) + segment.fontSize) / best.lines.length;
    } else {
      blocks.push({
        lines: [segment],
        x: segment.x,
        right: segment.right,
        top: segment.top,
        bottom: segment.bottom,
        w: segment.w,
        h: segment.h,
        fontSize: segment.fontSize,
        text: segment.text,
        bold: segment.bold,
      });
    }
  }

  // 4) 过滤掉页码、公式碎片、页眉页脚等
  const pageW = p.pageW;
  const pageH = p.pageH;
  const result = [];

  for (const block of blocks) {
    block.text = block.text.replace(/\s+/g, ' ').trim();
    if (!block.text || block.text.length < 2) continue;
    if (!/[A-Za-z\u00C0-\u024F]/.test(block.text)) continue;
    if (/^\s*\d{1,4}\s*$/.test(block.text)) continue;

    // 太窄的碎块通常是公式上下标、图里的单个字母，无法承载译文
    if (block.w < pageW * 0.03) continue;

    // 页眉 / 页脚 / arXiv 标识
    if (block.top < pageH * 0.032 && block.text.length < 60) continue;
    if (block.bottom > pageH * 0.97 && block.text.length < 40) continue;
    if (/^(arxiv|doi|https?:\/\/|©|copyright)/i.test(block.text) && block.text.length < 90) continue;

    // 图表/表格内的短标签：不参与正文重排，稍后在译文底图上原位替换。
    // 小字号的长文本（脚注、参考文献）仍按正文处理。
    block.isLabel =
      (block.fontSize < 8.4 && block.text.length < 80) ||
      (block.fontSize < 10.6 && block.lines.length <= 2 && block.text.length < 60);

    // 公式、符号碎片
    const letters = (block.text.match(/[A-Za-z]/g) || []).length;
    const symbols = (block.text.match(/[^A-Za-z0-9\s.,;:!?'"()[\]{}<>+\-–—/\\%&*]/g) || []).length;
    if (block.text.length < 90 && symbols > block.text.length * 0.42 && letters < block.text.length * 0.5) {
      continue;
    }

    const mathSymbols = (block.text.match(/[=<>√∑∫±×÷≤≥≈∞∂∇μπθλ]/g) || []).length;
    const words = (block.text.match(/[A-Za-z]{3,}/g) || []).length;
    if (mathSymbols >= 2 && words <= 5) continue;

    // 表格数据行：数字占比很高，原样保留在底图里，不做擦除/翻译，
    // 避免整块白底把表格线和数据一起盖掉。
    const digitCount = (block.text.match(/\d/g) || []).length;
    if (
      block.fontSize < 10.5 &&
      block.text.length < 140 &&
      digitCount >= 2 &&
      digitCount / Math.max(1, letters) > 0.35
    ) {
      continue;
    }

    // 连续 3 个以上纯数字 token 基本只出现在表格数据行里。
    // 这种块整块保留原文，避免白底把整张表擦掉。
    let numericRun = 0;
    let maxNumericRun = 0;
    for (const token of block.text.split(/\s+/)) {
      if (/^[-+]?\d+(?:[.,]\d+)?%?$/.test(token)) {
        numericRun += 1;
        maxNumericRun = Math.max(maxNumericRun, numericRun);
      } else {
        numericRun = 0;
      }
    }
    if (maxNumericRun >= 3) continue;

    // 多行块如果第一行几乎全是数字，也按表格处理。
    const firstLine = block.lines[0]?.text || '';
    const firstDigits = (firstLine.match(/\d/g) || []).length;
    const firstLetters = (firstLine.match(/[A-Za-z]/g) || []).length;
    if (
      block.lines.length >= 2 &&
      firstDigits >= 3 &&
      firstDigits / Math.max(1, firstLetters) > 0.6
    ) {
      continue;
    }

    block.y = block.top;
    block.align = detectAlign(block, p);
    block.growH = block.h;
    block.id = '';
    result.push(block);
  }

  result.sort((a, b) => a.y - b.y || a.x - b.x);

  // 去掉完全落在另一个大块里面的碎片（行内公式、图上零散文字），
  // 否则它们会在译文页与大段落叠在一起。
  const filtered = [];
  for (const block of result) {
    const area = Math.max(1, block.w * block.h);
    let covered = false;

    for (const other of filtered) {
      if (other.w * other.h <= area * 1.4) continue;
      const overlapW =
        Math.min(block.right, other.right) - Math.max(block.x, other.x);
      const overlapH =
        Math.min(block.bottom, other.bottom) - Math.max(block.top, other.top);
      if (overlapW <= 0 || overlapH <= 0) continue;
      if ((overlapW * overlapH) / area > 0.6) {
        covered = true;
        break;
      }
    }

    if (!covered) filtered.push(block);
  }

  result.length = 0;
  result.push(...filtered);
  result.sort((a, b) => a.y - b.y || a.x - b.x);

  computeBlockGrow(result, pageH);

  // 密集区域里互相压住的正文块通常无法在右侧正常重排，直接放弃；
  // 图表标签是原位替换，不依赖 growH，保留下来。
  const visible = result.filter(
    (block) => block.isLabel || block.growH >= Math.max(4, block.h * 0.45)
  );
  computeBlockGrow(visible, pageH);
  visible.sort((a, b) => a.y - b.y || a.x - b.x);

  visible.forEach((block, index) => {
    block.id = `${p.n}:${index}`;
    block.bold = block.lines.filter((line) => line.bold).length >= Math.max(1, block.lines.length * 0.6);
  });

  return { blocks: visible, pageW, pageH, textRects };
}

/**
 * 通过「页面中线附近是否有文字」来判断双栏版式。
 * 只看同一基线上的间距不够可靠：左右栏的基线可能相差 1–2pt，
 * 会被拆成两行，反而检测不到栏缝。
 */
// 计算每块向下可扩展的空间，便于译文放不下时自然撑开；
// 如果原文块本身就和下一块有重叠，则收紧到下一块之前，避免译文互相覆盖。
function computeBlockGrow(blocks, pageH) {
  for (const block of blocks) {
    let nextTop = pageH - 10;

    for (const other of blocks) {
      if (other === block || other.y <= block.y + 0.5) continue;
      const overlap = Math.min(block.right, other.right) - Math.max(block.x, other.x);
      if (overlap > Math.min(block.w, other.w) * 0.25) {
        nextTop = Math.min(nextTop, other.y);
      }
    }

    const available = nextTop - block.y - 1;
    const cap = block.h * 2 + block.fontSize * 1.2;
    block.growH = Math.max(3, Math.min(available, cap));
  }
}

function detectColumnSplit(items, pageW, pageH) {
  const center = pageW / 2;
  const bandHeight = Math.max(14, pageH / 50);
  const bands = new Map();

  for (const item of items) {
    const top = item.top;
    const bottom = item.baseline + item.fontH * 0.22;
    const startBand = Math.floor(top / bandHeight);
    const endBand = Math.floor(bottom / bandHeight);

    for (let band = startBand; band <= endBand; band += 1) {
      let record = bands.get(band);
      if (!record) {
        record = { left: false, right: false, center: false };
        bands.set(band, record);
      }

      if (item.x + item.w < center) record.left = true;
      if (item.x > center) record.right = true;
      if (item.x < center + pageW * 0.008 && item.x + item.w > center - pageW * 0.008) {
        record.center = true;
      }
    }
  }

  let twoColumnBands = 0;
  let singleColumnBands = 0;

  for (const record of bands.values()) {
    if (!record.left && !record.right) continue;
    if (record.center) singleColumnBands += 1;
    else if (record.left && record.right) twoColumnBands += 1;
  }

  return twoColumnBands >= 4 && twoColumnBands > singleColumnBands * 1.5 ? center : 0;
}

function finalizeSegment(segment) {
  const xs = segment.items.map((item) => item.x);
  const rights = segment.items.map((item) => item.x + item.w);
  const baselines = segment.items.map((item) => item.baseline);
  const fontSize = median(segment.items.map((item) => item.fontH)) || 10;

  const x = Math.min(...xs);
  const right = Math.max(...rights);
  // 用主字号而不是单个字符的外框来估行高，避免公式里的上下标把行撑高
  const top = Math.min(...baselines) - fontSize * 0.82;
  const bottom = Math.max(...baselines) + fontSize * 0.24;

  let text = '';
  let previous = null;
  for (const item of segment.items) {
    if (!previous) {
      text = item.str;
    } else {
      const gap = item.x - (previous.x + previous.w);
      const needSpace =
        !/\s$/.test(text) &&
        !/^\s/.test(item.str) &&
        gap > item.fontH * 0.12;
      text += (needSpace ? ' ' : '') + item.str;
    }
    previous = item;
  }

  return {
    x,
    right,
    top,
    bottom,
    w: Math.max(0.1, right - x),
    h: Math.max(0.1, bottom - top),
    fontSize,
    bold: segment.items.filter((item) => item.bold).length / segment.items.length > 0.5,
    text: text.replace(/\s+/g, ' ').trim(),
  };
}

function joinTexts(first, second) {
  const a = (first || '').trim();
  const b = (second || '').trim();
  if (!a) return b;
  if (!b) return a;
  if (/[\-‐]$/.test(a) && /^[a-z]/.test(b)) return a.replace(/[\-‐]$/, '') + b;
  return `${a} ${b}`;
}

function detectAlign(block, p) {
  const pageCenter = p.pageW / 2;

  if (block.lines.length === 1) {
    const center = (block.x + block.right) / 2;
    if (Math.abs(center - pageCenter) < p.pageW * 0.045 && block.w < p.pageW * 0.9) return 'center';
    return 'left';
  }

  const centers = block.lines.map((line) => (line.x + line.right) / 2);
  const average = centers.reduce((sum, value) => sum + value, 0) / centers.length;
  const stable = centers.every((center) => Math.abs(center - average) < 4);
  if (stable && Math.abs(average - pageCenter) < p.pageW * 0.045) return 'center';
  return 'left';
}

function layoutPage(p) {
  if (!p.model) return;

  buildHits(p);

  if (p.hasTranslation && state.viewMode !== 'original') {
    renderTranslation(p, true);
  } else {
    updatePageStatus(p);
  }

  p.layoutDirty = false;
}

function buildHits(p) {
  if (!p.model) return;

  p.hits.textContent = '';
  p.hitEls.clear();

  const fragment = document.createDocumentFragment();

  for (const block of p.model.blocks) {
    const hit = document.createElement('div');
    hit.className = 'hit';
    hit.dataset.id = block.id;
    hit.style.left = `${block.x * p.scale}px`;
    hit.style.top = `${block.y * p.scale}px`;
    hit.style.width = `${Math.max(2, block.w * p.scale)}px`;
    hit.style.height = `${Math.max(2, block.h * p.scale)}px`;
    fragment.appendChild(hit);
    p.hitEls.set(block.id, hit);
  }

  p.hits.appendChild(fragment);
}

/* ============================ 译文渲染 ============================ */

function renderTranslation(p, force = false) {
  if (!p.model) return;
  if (state.viewMode === 'original') return;

  if (p.hasTranslation) scheduleGhost(p);
  if (
    !force &&
    p.blocksRendered &&
    p.renderedVersion === p.transVersion &&
    Math.abs(p.renderedScale - p.scale) < 0.0005
  ) {
    return;
  }

  const layer = p.tblocks;
  layer.textContent = '';
  p.blockEls.clear();

  if (!p.hasTranslation) {
    p.blocksRendered = false;
    p.renderedVersion = p.transVersion;
    updatePageStatus(p);
    return;
  }

  const fragment = document.createDocumentFragment();
  const jobs = [];

  for (const block of p.model.blocks) {
    const translated = p.translations.get(block.id);
    if (!translated) continue;

    // 图表/表格标签在底图上原位绘制，不参与 DOM 重排。
    // 关闭“保留图表”时没有底图，退回普通文字块显示。
    if (block.isLabel && state.settings.keepGraphics) continue;

    const node = document.createElement('div');
    node.className = 'tblock';
    if (block.isLabel) {
      node.classList.add('is-label', 'is-center');
    } else {
      if (block.align === 'center') node.classList.add('is-center');
      if (block.h > block.fontSize * 1.65 && block.align !== 'center') node.classList.add('is-justify');
    }
    if (block.bold) node.classList.add('is-bold');

    node.style.left = `${block.x * p.scale}px`;
    node.style.top = `${block.y * p.scale}px`;
    node.style.width = `${Math.max(8, block.w * p.scale)}px`;
    node.style.height = `${Math.max(5, block.h * p.scale)}px`;
    node.dataset.id = block.id;
    node.textContent = translated;

    fragment.appendChild(node);
    p.blockEls.set(block.id, node);
    jobs.push([node, block]);
  }

  layer.appendChild(fragment);

  p.blocksRendered = true;
  p.renderedVersion = p.transVersion;
  p.renderedScale = p.scale;
  p.statusEl.hidden = true;

  requestAnimationFrame(() => {
    for (const [node, block] of jobs) fitBlock(node, block, p);
  });
}

function fitBlock(node, block, p) {
  const base = block.fontSize * p.scale * (state.settings.fontScale || 1);
  const start = clamp(base, 6.5, 42);
  const min = Math.max(6, start * 0.55);
  const originalHeight = Math.max(4, block.h * p.scale);
  const maxHeight = Math.max(4, block.growH * p.scale);
  const firstHeight = Math.min(originalHeight, maxHeight);

  node.style.height = `${firstHeight}px`;
  if (textFits(node, start)) {
    node.style.fontSize = `${start}px`;
    return;
  }

  node.style.height = `${maxHeight}px`;
  if (textFits(node, start)) {
    node.style.fontSize = `${start}px`;
    return;
  }

  let low = min;
  let high = start;
  let best = min;

  for (let i = 0; i < 7; i += 1) {
    const middle = (low + high) / 2;
    if (textFits(node, middle)) {
      best = middle;
      low = middle;
    } else {
      high = middle;
    }
  }

  node.style.fontSize = `${best}px`;
  if (!textFits(node, best)) node.classList.add('is-clipped');
}

function textFits(node, fontSize) {
  node.style.fontSize = `${fontSize}px`;
  return node.scrollHeight <= node.clientHeight + 0.8;
}

/**
 * 译文页底图：把原文页面复制一份，擦掉已经翻译的正文区域，
 * 保留图表、公式、表格线等非正文内容，再在上面叠加中文。
 */
function scheduleGhost(p) {
  if (!state.settings.keepGraphics || !p.hasTranslation || state.viewMode === 'original') {
    clearGhost(p);
    return;
  }
  if (!nearViewport(p, 1400)) return;
  renderGhost(p).catch((err) => console.warn('[译镜] 底图渲染失败', p.n, err));
}

async function renderGhost(p) {
  if (!p.ghost || !p.page) return;
  if (!state.settings.keepGraphics || !p.hasTranslation) {
    clearGhost(p);
    return;
  }
  if (p.ghostRendering) {
    p.ghostAgain = true;
    return;
  }
  if (
    p.ghostReady &&
    p.ghostVersion === p.transVersion &&
    Math.abs(p.ghostScale - p.scale) < 0.0005
  ) {
    return;
  }

  p.ghostRendering = true;

  try {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const viewport = p.page.getViewport({ scale: p.scale * dpr });
    const width = Math.max(1, Math.round(viewport.width));
    const height = Math.max(1, Math.round(viewport.height));

    // 双栏模式下等左侧原文画布先画完，直接复制，避免同一页并发渲染。
    // 只有「只看译文」模式才单独渲染一份底图。
    if (
      state.viewMode !== 'translated' &&
      (!p.canvasRendered || p.canvas.width !== width || p.canvas.height !== height)
    ) {
      return;
    }

    // 先在离屏画布上完成「复制原文 + 擦除正文」，再一次性贴到可见底图上，
    // 这样放大/重绘时不会出现白页或英文闪烁。
    const base = document.createElement('canvas');
    base.width = width;
    base.height = height;
    const baseContext = base.getContext('2d', {
      alpha: false,
      willReadFrequently: true,
    });

    if (p.canvasRendered && p.canvas.width === width && p.canvas.height === height) {
      baseContext.drawImage(p.canvas, 0, 0, width, height);
    } else {
      baseContext.fillStyle = '#ffffff';
      baseContext.fillRect(0, 0, width, height);

      const task = p.page.render({ canvasContext: baseContext, viewport });
      try {
        await task.promise;
      } catch (err) {
        if (err?.name !== 'RenderingCancelledException') throw err;
      }
    }

    // 擦除已经翻译的正文块；图表标签单独做“只擦文字、不擦图形”的处理
    const pad = 1.5;
    const labelJobs = [];
    const canvasScale = p.scale * dpr;

    baseContext.save();
    baseContext.fillStyle = '#ffffff';

    for (const block of p.model.blocks) {
      const translated = p.translations.get(block.id);
      if (!translated) continue;

      if (block.isLabel) {
        labelJobs.push([block, translated]);
        continue;
      }

      baseContext.fillRect(
        (block.x - pad) * canvasScale,
        (block.y - pad) * canvasScale,
        (block.w + pad * 2) * canvasScale,
        (block.h + pad * 2) * canvasScale
      );
    }

    baseContext.restore();

    // 标签：先按颜色把原文字像素抹成背景色，再在同一个框里写中文
    for (const [block, translated] of labelJobs) {
      const colors = eraseLabelGlyphs(baseContext, block, canvasScale);
      if (colors) drawLabelText(baseContext, block, translated, canvasScale, colors);
    }

    if (p.ghost.width !== width || p.ghost.height !== height) {
      p.ghost.width = width;
      p.ghost.height = height;
    }

    const context = p.ghost.getContext('2d', { alpha: false });
    context.drawImage(base, 0, 0);
    base.width = 0;
    base.height = 0;

    p.ghostReady = true;
    p.ghostVersion = p.transVersion;
    p.ghostScale = p.scale;
  } finally {
    p.ghostRendering = false;
    if (p.ghostAgain) {
      p.ghostAgain = false;
      if (nearViewport(p)) renderGhost(p);
    }
  }
}

/**
 * 抹掉标签框里的文字像素，保留方框、填充色和线条。
 * 做法：取框内出现最多的颜色作为背景，把明显偏离背景、
 * 且更接近文字颜色的像素替换成背景色。
 */
function eraseLabelGlyphs(context, block, scale) {
  const x = Math.max(0, Math.floor(block.x * scale));
  const y = Math.max(0, Math.floor(block.y * scale));
  const width = Math.min(context.canvas.width - x, Math.ceil(block.w * scale));
  const height = Math.min(context.canvas.height - y, Math.ceil(block.h * scale));

  if (width < 2 || height < 2) return null;

  let image;
  try {
    image = context.getImageData(x, y, width, height);
  } catch {
    // 画布被跨域图片污染时无法读写像素，放弃原位替换
    return null;
  }

  const data = image.data;
  const counts = new Map();

  for (let i = 0; i < data.length; i += 4) {
    const key =
      ((data[i] >> 4) << 8) | ((data[i + 1] >> 4) << 4) | (data[i + 2] >> 4);
    counts.set(key, (counts.get(key) || 0) + 1);
  }

  let bestKey = 0;
  let bestCount = -1;
  for (const [key, count] of counts) {
    if (count > bestCount) {
      bestCount = count;
      bestKey = key;
    }
  }

  let red = 0;
  let green = 0;
  let blue = 0;
  let sum = 0;

  for (let i = 0; i < data.length; i += 4) {
    const key =
      ((data[i] >> 4) << 8) | ((data[i + 1] >> 4) << 4) | (data[i + 2] >> 4);
    if (key !== bestKey) continue;
    red += data[i];
    green += data[i + 1];
    blue += data[i + 2];
    sum += 1;
  }

  if (!sum) return null;

  const background = [red / sum, green / sum, blue / sum];
  const backgroundLum = luminance(background);

  const candidates = [];
  for (let i = 0; i < data.length; i += 4) {
    const distance = colorDistance(data[i], data[i + 1], data[i + 2], background);
    if (distance > 42) candidates.push({ index: i, distance });
  }

  if (!candidates.length) return null;

  candidates.sort((a, b) => b.distance - a.distance);
  const take = Math.max(1, Math.floor(candidates.length * 0.12));

  let textRed = 0;
  let textGreen = 0;
  let textBlue = 0;

  for (let i = 0; i < take; i += 1) {
    const index = candidates[i].index;
    textRed += data[index];
    textGreen += data[index + 1];
    textBlue += data[index + 2];
  }

  const textColor = [textRed / take, textGreen / take, textBlue / take];

  // 标签框通常只包住一行文字：直接用局部背景色覆盖整个框，
  // 比逐像素判断更干净，也能去掉抗锯齿残留。框外的方框/连线不受影响。
  const isOcr = block.source === 'ocr';
  const padX = isOcr ? Math.max(0.6, block.fontSize * 0.25) : 0.6;
  const padY = isOcr ? Math.max(0.6, block.fontSize * 0.15) : 0.6;

  const fillX = (block.x - padX) * scale;
  const fillY = (block.y - padY) * scale;
  const fillW = (block.w + padX * 2) * scale;
  const fillH = (block.h + padY * 2) * scale;

  context.save();
  context.fillStyle = `rgb(${Math.round(background[0])}, ${Math.round(background[1])}, ${Math.round(background[2])})`;
  context.fillRect(fillX, fillY, fillW, fillH);
  context.restore();

  return {
    background,
    text: textColor,
    backgroundCss: `rgb(${Math.round(background[0])}, ${Math.round(background[1])}, ${Math.round(background[2])})`,
    textCss: `rgb(${Math.round(textColor[0])}, ${Math.round(textColor[1])}, ${Math.round(textColor[2])})`,
    backgroundLum,
  };
}

/** 在标签原来的框里写中文，字号自动收缩，居中。 */
function drawLabelText(context, block, text, scale, colors) {
  const x = block.x * scale;
  const y = block.y * scale;
  const width = Math.max(3, block.w * scale);
  const height = Math.max(3, block.h * scale);
  const maxWidth = Math.max(3, width - 1);
  const maxHeight = Math.max(3, height + 1);

  let size = clamp(block.fontSize * scale * 1.05, 4, 72);
  const family = '"Microsoft YaHei", "PingFang SC", "Segoe UI", sans-serif';
  const weight = block.bold ? '600 ' : '';
  let lines = [text];

  for (let attempt = 0; attempt < 18; attempt += 1) {
    context.font = `${weight}${size}px ${family}`;
    lines = wrapCanvasText(context, text, maxWidth);

    const lineHeight = size * 1.08;
    const totalHeight = lines.length * lineHeight;

    if (totalHeight <= maxHeight + 0.5) break;
    size *= 0.92;
    if (size < 4) break;
  }

  const lineHeight = size * 1.08;
  const totalHeight = lines.length * lineHeight;
  const startY = y + (height - totalHeight) / 2 + lineHeight / 2;

  context.save();
  context.beginPath();
  context.rect(x, y, width, height);
  context.clip();

  context.font = `${weight}${size}px ${family}`;
  context.textAlign = 'center';
  context.textBaseline = 'middle';

  // 用背景色描一圈，抵消没有完全擦干净的英文边缘
  context.strokeStyle = colors.backgroundCss;
  context.lineWidth = Math.max(1, size * 0.07);
  context.lineJoin = 'round';

  context.fillStyle = colors.textCss;

  for (let i = 0; i < lines.length; i += 1) {
    const lineY = startY + i * lineHeight;
    context.strokeText(lines[i], x + width / 2, lineY);
    context.fillText(lines[i], x + width / 2, lineY);
  }

  context.restore();
}

function wrapCanvasText(context, text, maxWidth) {
  if (context.measureText(text).width <= maxWidth) return [text];

  const tokens = text.match(/[A-Za-z0-9.,:;!?'"()[\]{}%+\-–—/]+|[\u4e00-\u9fff]|\s+|./g) || [text];
  const lines = [];
  let line = '';

  const pushLine = () => {
    if (line.trim()) lines.push(line.trim());
    line = '';
  };

  for (const token of tokens) {
    if (!line && /^\s+$/.test(token)) continue;

    if (context.measureText(line + token).width <= maxWidth) {
      line += token;
      continue;
    }

    if (line) pushLine();

    if (context.measureText(token).width <= maxWidth) {
      line = token;
      continue;
    }

    for (const character of Array.from(token)) {
      if (line && context.measureText(line + character).width > maxWidth) pushLine();
      line += character;
    }
  }

  pushLine();
  return lines.length ? lines : [text];
}

function luminance(color) {
  return 0.299 * color[0] + 0.587 * color[1] + 0.114 * color[2];
}

function colorDistance(red, green, blue, color) {
  const dr = red - color[0];
  const dg = green - color[1];
  const db = blue - color[2];
  return Math.sqrt(dr * dr + dg * dg + db * db);
}

function clearGhost(p) {
  if (!p.ghost) return;
  p.ghost.width = 0;
  p.ghost.height = 0;
  p.ghostReady = false;
  p.ghostVersion = -1;
  p.ghostScale = 0;
}

function updatePageStatus(p) {
  if (!p.statusEl) return;

  if (p.hasTranslation) {
    p.statusEl.hidden = true;
    return;
  }

  p.statusEl.classList.toggle('is-error', p.status === 'error');
  const spinner = p.statusEl.querySelector('.spinner');

  if (p.referencesOnly) {
    spinner.hidden = true;
    p.statusText.textContent = '参考文献页 · 已跳过翻译';
    p.statusEl.hidden = false;
    return;
  }

  if (p.status === 'ocr') {
    spinner.hidden = false;
    p.statusText.textContent = '正在识别图表文字…';
    p.statusEl.hidden = false;
    return;
  }

  if (p.status === 'error') {
    spinner.hidden = true;
    p.statusText.textContent = '翻译失败 · 点击重试';
    p.statusEl.hidden = false;
    return;
  }

  if (p.status === 'translating' || p.status === 'queued') {
    spinner.hidden = false;
    p.statusText.textContent = p.status === 'queued' ? '排队中…' : '正在翻译…';
    p.statusEl.hidden = false;
    return;
  }

  if (p.status === 'done' && p.model && p.model.blocks.length === 0) {
    spinner.hidden = true;
    p.statusText.textContent = '此页没有可提取的文字';
    p.statusEl.hidden = false;
    return;
  }

  p.statusEl.hidden = true;
}

/* ============================ 悬停联动 ============================ */

function bindPageHover(p) {
  p.tblocks.addEventListener('mouseover', (event) => {
    const node = event.target.closest('.tblock');
    if (!node) return;

    p.hitEls.get(node.dataset.id)?.classList.add('is-hover');
    const block = p.model?.blocks.find((item) => item.id === node.dataset.id);
    if (block) {
      const clipped = node.classList.contains('is-clipped');
      const tip = clipped
        ? `译文（完整）：${node.textContent}\n\n原文：${block.text}`
        : block.text;
      showHoverTip(tip, event);
    }
  });

  p.tblocks.addEventListener('mouseout', (event) => {
    const node = event.target.closest('.tblock');
    if (!node) return;
    p.hitEls.get(node.dataset.id)?.classList.remove('is-hover');
    hideHoverTip();
  });

  p.hits.addEventListener('mouseover', (event) => {
    const hit = event.target.closest('.hit');
    if (!hit) return;
    p.blockEls.get(hit.dataset.id)?.classList.add('is-hover');
  });

  p.hits.addEventListener('mouseout', (event) => {
    const hit = event.target.closest('.hit');
    if (!hit) return;
    p.blockEls.get(hit.dataset.id)?.classList.remove('is-hover');
  });
}

function showHoverTip(text, event) {
  if (!text) return;

  ui.hoverTip.textContent = text;
  ui.hoverTip.hidden = false;

  const rect = ui.hoverTip.getBoundingClientRect();
  let left = event.clientX + 16;
  let top = event.clientY + 16;

  if (left + rect.width > window.innerWidth - 10) left = event.clientX - rect.width - 16;
  if (top + rect.height > window.innerHeight - 10) top = event.clientY - rect.height - 16;

  ui.hoverTip.style.left = `${Math.max(8, left)}px`;
  ui.hoverTip.style.top = `${Math.max(8, top)}px`;
}

function hideHoverTip() {
  ui.hoverTip.hidden = true;
}

/* ============================ 翻译流程 ============================ */

async function startTranslation(pagesToDo) {
  if (state.translating) {
    stopTranslation();
    return;
  }

  if (!hasTranslationConfig()) {
    showSetupBanner(true);
    showNotice('还没有配置翻译服务。请选择 DeepSeek / 百度翻译 / MyMemory 并完成设置。', [
      { label: '打开设置', onClick: openOptions },
    ]);
    return;
  }

  if (!state.pdf) return;

  const queue = (pagesToDo || state.pages).filter((p) => p.status !== 'done');
  if (!queue.length) return;

  state.translating = true;
  state.translationStarted = true;
  state.fatalError = null;
  state.abort = new AbortController();
  const signal = state.abort.signal;

  for (const p of queue) {
    p.status = 'queued';
    p.error = null;
    updatePageStatus(p);
  }

  updateTranslateButton();
  hideNotice();

  const concurrency = clamp(Number(state.settings.concurrency) || 2, 1, 4);
  let cursor = 0;

  const worker = async () => {
    while (true) {
      if (signal.aborted) return;

      const index = cursor;
      cursor += 1;
      if (index >= queue.length) return;

      const p = queue[index];
      if (p.status === 'done') continue;

      try {
        await translatePage(p, signal);
      } catch (err) {
        if (err?.name === 'AbortError') return;

        p.status = 'error';
        p.error = err;
        p.transVersion += 1;
        updatePageStatus(p);

        if (err?.fatal) {
          state.fatalError = err;
          state.abort.abort();
        }
        console.warn('[译镜] 翻译失败', p.n, err);
      }

      updateTranslateButton();
    }
  };

  try {
    const workerCount = Math.min(concurrency, queue.length);
    await Promise.all(Array.from({ length: workerCount }, () => worker()));
  } finally {
    const wasAborted = Boolean(signal.aborted);

    for (const p of state.pages) {
      if (p.status === 'queued' || p.status === 'translating') {
        p.status = 'idle';
        updatePageStatus(p);
      }
    }

    state.translating = false;
    state.abort = null;
    updateTranslateButton();

    if (state.fatalError) {
      showNotice(`翻译服务出错：${state.fatalError.message}`, [
        { label: '检查设置', onClick: openOptions },
      ], 'error');
    } else if (wasAborted) {
      // 用户主动停止：保留已完成的页面
    } else {
      const failed = state.pages.filter((p) => p.status === 'error');
      const totalBlocks = state.pages.reduce((sum, p) => sum + (p.model?.blocks.length || 0), 0);

      if (failed.length) {
        showNotice(
          `有 ${failed.length} 页没有翻译成功，可重试失败的页面。`,
          [{ label: '重试失败页', onClick: () => startTranslation(failed) }],
          'error'
        );
      } else if (totalBlocks === 0) {
        showNotice('没有从这份 PDF 中提取到文字，可能是扫描版。扫描版需要 OCR，暂时无法翻译。', [], 'error');
      } else {
        toast('翻译完成');
      }
    }
  }
}

function stopTranslation() {
  if (!state.translating) return;
  state.abort?.abort();
  state.translating = false;
  updateTranslateButton();
  toast('已停止翻译');
}

function retryPage(p) {
  if (state.translating) return;
  p.status = 'idle';
  p.error = null;
  startTranslation([p]);
}

async function translatePage(p, signal) {
  p.status = 'translating';
  updatePageStatus(p);

  const model = await ensureModel(p);

  if (state.settings.ocrFigures && !p.ocrDone && (await pageHasImages(p))) {
    p.status = 'ocr';
    updatePageStatus(p);
    await ensureOcr(p);

    if (signal.aborted) {
      throw Object.assign(new Error('已停止'), { name: 'AbortError' });
    }

    p.status = 'translating';
    updatePageStatus(p);
  }

  applyReferenceFilter(p);

  if (!model.blocks.length) {
    p.status = 'done';
    p.done = true;
    p.hasTranslation = p.translations.size > 0;
    updatePageStatus(p);
    updateTranslateButton();
    return;
  }

  const todo = [];

  for (const block of model.blocks) {
    if (p.translations.has(block.id)) continue;

    const key = cacheKey(block.text);
    const cached = translationCache.get(key);

    if (cached) {
      p.translations.set(block.id, cached);
    } else {
      todo.push({ block, key });
    }
  }

  p.hasTranslation = p.translations.size > 0;

  if (!todo.length) {
    p.status = 'done';
    p.done = true;
    p.hasTranslation = p.translations.size > 0;
    p.transVersion += 1;

    if (nearViewport(p)) renderTranslation(p, true);
    else updatePageStatus(p);

    updateTranslateButton();
    return;
  }

  const batches = makeBatches(todo);

  const results = await mapLimit(batches, 2, async (items) => {
    try {
      const values = await translateBatchWithFallback(items.map((item) => item.block), signal);
      return { ok: true, items, values };
    } catch (err) {
      return { ok: false, items, error: err };
    }
  });

  if (signal.aborted) {
    throw Object.assign(new Error('已停止'), { name: 'AbortError' });
  }

  let firstError = null;
  let fatalError = null;

  for (const result of results) {
    if (!result.ok) {
      firstError ||= result.error;
      if (result.error?.fatal) fatalError = result.error;
      continue;
    }

    for (const item of result.items) {
      const translated = result.values.get(item.block.id);
      if (!translated) continue;
      p.translations.set(item.block.id, translated);
      translationCache.set(item.key, translated);
    }
  }

  p.hasTranslation = p.translations.size > 0;
  p.transVersion += 1;
  saveCache();

  if (fatalError) {
    p.status = 'error';
    p.error = fatalError;
    updatePageStatus(p);
    throw fatalError;
  }

  if (firstError) {
    p.status = 'error';
    p.error = firstError;
  } else {
    p.status = 'done';
    p.done = true;
  }

  if (nearViewport(p)) renderTranslation(p, true);
  else updatePageStatus(p);

  updateTranslateButton();

  if (firstError) throw firstError;
}

function makeBatches(items) {
  const maxChars = clamp(Number(state.settings.batchChars) || 1600, 500, 4000);
  const maxItems = 16;

  const batches = [];
  let current = [];
  let chars = 0;

  for (const item of items) {
    const length = item.block.text.length;

    if (current.length && (chars + length > maxChars || current.length >= maxItems)) {
      batches.push(current);
      current = [];
      chars = 0;
    }

    current.push(item);
    chars += length;
  }

  if (current.length) batches.push(current);
  return batches;
}

async function translateBatchWithFallback(blocks, signal) {
  try {
    return await translateBatch(blocks, signal);
  } catch (err) {
    if (err?.fatal || err?.name === 'AbortError' || blocks.length <= 1) throw err;

    const middle = Math.ceil(blocks.length / 2);
    const [first, second] = await Promise.all([
      translateBatchWithFallback(blocks.slice(0, middle), signal),
      translateBatchWithFallback(blocks.slice(middle), signal),
    ]);

    return new Map([...first, ...second]);
  }
}

const SYSTEM_PROMPT = `你是一名专业的学术论文翻译引擎。请把用户给出的英文片段逐条翻译成{lang}。

严格规则：
1. 输入是 JSON 数组，输出也必须是 JSON 字符串数组；长度、顺序与输入完全一致，不要输出任何解释或代码块标记。
2. 每条只翻译对应片段，不合并、不拆分、不遗漏；不添加注释、前缀或后缀。
3. 原样保留：数学公式与符号、变量名、数字、引用编号（如 [12]）、图表编号（如 Fig. 2）、URL、DOI、邮箱、代码。
4. 学科术语采用该领域通行译法；没有通行译名的专有名词可保留英文。
5. 保持学术语体，简洁准确；标题保持标题的简洁风格。
6. 遇到断词连字符（如 "trans- former"）时按完整单词理解后翻译，不要保留多余的连字符。
7. 带 "label": true 的条目是图/表/示意图里的短标签。译文必须极简（通常 2–8 个字），保留变量名、数字、单位、缩写和符号；没有通行译名的专有名词保留原文，宁短勿长。`;

async function translateBatch(blocks, signal) {
  const provider = state.settings.provider;

  if (provider === 'baidu') return translateBaiduBatch(blocks, signal);
  if (provider === 'mymemory') return translateMyMemoryBatch(blocks, signal);

  return translateOpenAiBatch(blocks, signal);
}

async function translateOpenAiBatch(blocks, signal) {
  const payload = blocks.map((block, index) => ({
    i: index,
    text: block.text,
    ...(block.isLabel ? { label: true } : {}),
  }));
  const content = await chat(
    SYSTEM_PROMPT.replaceAll('{lang}', state.settings.targetLang),
    JSON.stringify(payload),
    signal
  );

  const array = parseTranslationArray(content);

  if (!Array.isArray(array) || array.length !== blocks.length) {
    throw new Error(`模型返回条数不正确（${array?.length ?? 0}/${blocks.length}）`);
  }

  const result = new Map();

  blocks.forEach((block, index) => {
    const value = array[index];
    const text =
      typeof value === 'string'
        ? value
        : value?.translation ?? value?.text ?? value?.zh ?? '';

    if (typeof text === 'string' && text.trim()) {
      result.set(block.id, text.trim());
    }
  });

  return result;
}

function baiduTargetLang() {
  return (
    {
      简体中文: 'zh',
      繁體中文: 'cht',
      日本語: 'jp',
      한국어: 'kor',
    }[state.settings.targetLang] || 'zh'
  );
}

function baiduErrorText(code) {
  return (
    {
      52001: '请求超时',
      52002: '系统错误',
      52003: 'AppID 无效或未授权',
      54000: '缺少必填参数',
      54001: '签名错误，请检查密钥',
      54003: '访问频率受限，请稍后重试',
      54004: '账户余额或免费额度不足',
      54005: '请求文本过长',
      58000: '客户端 IP 非法',
      58001: '语言方向不支持',
      58002: '服务已关闭',
    }[String(code)] || `错误码 ${code}`
  );
}

async function translateBaiduBatch(blocks, signal) {
  const { appId, appSecret } = state.settings;

  if (!appId || !appSecret) {
    throw new ApiError('还没有填写百度 AppID 或密钥', { fatal: true });
  }

  const q = blocks.map((block) => block.text.replace(/\n+/g, ' ')).join('\n');

  if (new TextEncoder().encode(q).length > 5800) {
    throw new Error('百度翻译单次文本过长，请降低高级选项里的每批字符数');
  }

  await baiduGate.acquire();

  try {
    let result = null;

    for (let attempt = 0; attempt < 3; attempt += 1) {
      if (signal.aborted) throw Object.assign(new Error('已停止'), { name: 'AbortError' });

      const wait = Math.max(0, baiduNextRequestAt - Date.now());
      if (wait) await sleep(wait);
      baiduNextRequestAt = Date.now() + 1150;

      const salt = String(Date.now());
      const sign = md5(appId + q + salt + appSecret);

      let response;
      try {
        response = await fetch('https://fanyi-api.baidu.com/api/trans/vip/translate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: new URLSearchParams({
            q,
            from: 'en',
            to: baiduTargetLang(),
            appid: appId,
            salt,
            sign,
          }),
          signal,
        });
      } catch (err) {
        if (err?.name === 'AbortError') throw err;
        if (attempt < 2) {
          await sleep(1200 * (attempt + 1));
          continue;
        }
        throw new ApiError(`无法连接百度翻译：${err.message || '网络错误'}`, { fatal: false });
      }

      let data = null;
      try {
        data = await response.json();
      } catch {
        data = null;
      }

      if (!data) {
        if (attempt < 2) {
          await sleep(1200 * (attempt + 1));
          continue;
        }
        throw new ApiError('百度翻译返回了非 JSON 数据', { fatal: false });
      }

      if (data.error_code) {
        const code = String(data.error_code);
        const transient = code === '52001' || code === '52002' || code === '54003';
        const fatal = ['52003', '54001', '54004', '58000', '58002'].includes(code);

        if (transient && attempt < 2) {
          await sleep(1800 * (attempt + 1));
          continue;
        }

        throw new ApiError(`百度翻译：${baiduErrorText(code)}`, {
          fatal,
          status: Number(code) || 0,
        });
      }

      const translations = Array.isArray(data.trans_result)
        ? data.trans_result
        : data.trans_result
          ? [data.trans_result]
          : [];

      if (translations.length !== blocks.length) {
        throw new Error(
          `百度翻译返回条数不正确（${translations.length}/${blocks.length}）`
        );
      }

      result = new Map(
        blocks.map((block, index) => [
          block.id,
          decodeHtmlEntities(String(translations[index]?.dst || '').trim()),
        ])
      );
      break;
    }

    if (!result) throw new ApiError('百度翻译请求失败', { fatal: false });
    return result;
  } finally {
    baiduGate.release();
  }
}

async function translateMyMemoryBatch(blocks, signal) {
  const result = new Map();
  const langPair = {
    简体中文: 'zh-CN',
    繁體中文: 'zh-TW',
    日本語: 'ja-JP',
    한국어: 'ko-KR',
  }[state.settings.targetLang] || 'zh-CN';

  for (const block of blocks) {
    if (signal.aborted) throw Object.assign(new Error('已停止'), { name: 'AbortError' });

    const pieces = splitMyMemoryText(block.text, 450);
    const parts = [];

    for (const piece of pieces) {
      parts.push(await translateMyMemoryPiece(piece, langPair, signal));
    }

    result.set(block.id, parts.join(' ').trim());
  }

  return result;
}

async function translateMyMemoryPiece(text, langPair, signal) {
  await myMemoryGate.acquire();

  try {
    for (let attempt = 0; attempt < 3; attempt += 1) {
      const wait = Math.max(0, myMemoryNextRequestAt - Date.now());
      if (wait) await sleep(wait);
      myMemoryNextRequestAt = Date.now() + 420;

      const url =
        'https://api.mymemory.translated.net/get?' +
        new URLSearchParams({ q: text, langpair: `en|${langPair}` }).toString();

      let response;
      try {
        response = await fetch(url, { signal });
      } catch (err) {
        if (err?.name === 'AbortError') throw err;
        if (attempt < 2) {
          await sleep(1000 * (attempt + 1));
          continue;
        }
        throw new ApiError(`无法连接 MyMemory：${err.message || '网络错误'}`, { fatal: false });
      }

      let data = null;
      try {
        data = await response.json();
      } catch {
        data = null;
      }

      if (!data) {
        if (attempt < 2) {
          await sleep(1000 * (attempt + 1));
          continue;
        }
        throw new ApiError('MyMemory 返回了非 JSON 数据', { fatal: false });
      }

      const status = Number(data.responseStatus || 0);
      const detail = String(data.responseDetails || '');

      if (status !== 200) {
        const quota = /quota|limit|too many|forbidden/i.test(detail);
        if (attempt < 2 && !quota) {
          await sleep(1200 * (attempt + 1));
          continue;
        }
        throw new ApiError(`MyMemory：${detail || `HTTP ${status}`}`, {
          fatal: quota || status === 403 || status === 429,
        });
      }

      const translated = decodeHtmlEntities(
        String(data.responseData?.translatedText || '').trim()
      );

      if (!translated) throw new Error('MyMemory 返回为空');
      if (/MYMEMORY WARNING|QUERY LENGTH LIMIT/i.test(translated)) {
        throw new ApiError('MyMemory 免费额度已用完', { fatal: true });
      }

      return translated;
    }

    throw new ApiError('MyMemory 请求失败', { fatal: false });
  } finally {
    myMemoryGate.release();
  }
}

function splitMyMemoryText(text, maxLength) {
  if (text.length <= maxLength) return [text];

  const pieces = [];
  let current = '';
  const sentences = text.split(/(?<=[.!?])\s+/);

  for (const sentence of sentences) {
    if ((current ? `${current} ${sentence}` : sentence).length <= maxLength) {
      current = current ? `${current} ${sentence}` : sentence;
      continue;
    }

    if (current) pieces.push(current);

    let rest = sentence;
    while (rest.length > maxLength) {
      let cut = rest.lastIndexOf(' ', maxLength);
      if (cut < maxLength * 0.5) cut = maxLength;
      pieces.push(rest.slice(0, cut).trim());
      rest = rest.slice(cut).trim();
    }

    current = rest;
  }

  if (current) pieces.push(current);
  return pieces.filter(Boolean);
}

function decodeHtmlEntities(text) {
  if (!text.includes('&')) return text;
  const textarea = document.createElement('textarea');
  textarea.innerHTML = text;
  return textarea.value;
}

function parseTranslationArray(raw) {
  if (!raw) throw new Error('模型返回为空');

  let text = String(raw).trim();
  text = text.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '').trim();

  try {
    const value = JSON.parse(text);
    if (Array.isArray(value)) return value;
    if (Array.isArray(value.translations)) return value.translations;
    if (Array.isArray(value.result)) return value.result;
    if (Array.isArray(value.data)) return value.data;
  } catch {
    /* 继续尝试截取数组 */
  }

  const start = text.indexOf('[');
  const end = text.lastIndexOf(']');
  if (start >= 0 && end > start) {
    try {
      const value = JSON.parse(text.slice(start, end + 1));
      if (Array.isArray(value)) return value;
    } catch {
      /* 忽略 */
    }
  }

  const lines = text
    .split('\n')
    .map((line) => line.trim())
    .filter(Boolean);

  if (lines.length) return lines;
  throw new Error('无法解析模型返回的内容');
}

async function chat(system, user, signal) {
  const base = normalizeBaseUrl(state.settings.baseUrl);

  if (!base) throw new ApiError('还没有填写接口地址', { fatal: true });
  if (!state.settings.model) throw new ApiError('还没有填写模型名称', { fatal: true });

  const response = await apiFetch(
    `${base}/chat/completions`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${state.settings.apiKey}`,
      },
      body: JSON.stringify({
        model: state.settings.model,
        messages: [
          { role: 'system', content: system },
          { role: 'user', content: user },
        ],
        temperature: 0.2,
        max_tokens: 4096,
        stream: false,
      }),
    },
    signal
  );

  let data;
  try {
    data = await response.json();
  } catch {
    throw new Error('翻译接口返回了非 JSON 数据');
  }

  const content = data?.choices?.[0]?.message?.content;
  if (typeof content !== 'string' || !content.trim()) {
    throw new Error('翻译接口没有返回内容');
  }

  return content;
}

async function apiFetch(url, init, signal, attempt = 0) {
  let response;

  try {
    response = await fetch(url, { ...init, signal });
  } catch (err) {
    if (err?.name === 'AbortError') throw err;

    if (attempt < 2) {
      await sleep(1000 * (attempt + 1));
      return apiFetch(url, init, signal, attempt + 1);
    }

    throw new ApiError(`无法连接翻译接口：${err.message || '网络错误'}`, { fatal: false });
  }

  if (response.ok) return response;

  let raw = '';
  try {
    raw = await response.text();
  } catch {
    /* ignore */
  }

  let message = raw;
  try {
    const parsed = JSON.parse(raw);
    message = parsed?.error?.message || parsed?.message || raw;
  } catch {
    /* 保持原文 */
  }

  const status = response.status;
  const fatal = status === 401 || status === 402 || status === 403;
  const error = new ApiError(
    `翻译接口返回 ${status}${message ? `：${String(message).slice(0, 240)}` : ''}`,
    { status, fatal }
  );

  if (!fatal && (status === 429 || status >= 500) && attempt < 2) {
    await sleep(status === 429 ? 2600 : 1000 * (attempt + 1));
    return apiFetch(url, init, signal, attempt + 1);
  }

  throw error;
}

class ApiError extends Error {
  constructor(message, { fatal = false, status = 0 } = {}) {
    super(message);
    this.name = 'ApiError';
    this.fatal = fatal;
    this.status = status;
  }
}

/* ============================ 翻译缓存 ============================ */

function cacheKey(text) {
  return fnv1a(`${state.settings.targetLang}\u0000${text}`);
}

function loadCache() {
  try {
    const raw = localStorage.getItem(CACHE_NAME);
    if (!raw) return;
    const data = JSON.parse(raw);
    for (const [key, value] of Object.entries(data)) {
      if (typeof value === 'string') translationCache.set(key, value);
    }
  } catch {
    /* 缓存损坏时忽略 */
  }
}

let cacheTimer = 0;

function saveCache() {
  clearTimeout(cacheTimer);
  cacheTimer = window.setTimeout(() => {
    try {
      if (translationCache.size > 3500) {
        const drop = translationCache.size - 3000;
        let removed = 0;
        for (const key of translationCache.keys()) {
          translationCache.delete(key);
          removed += 1;
          if (removed >= drop) break;
        }
      }
      localStorage.setItem(CACHE_NAME, JSON.stringify(Object.fromEntries(translationCache)));
    } catch {
      try {
        const entries = [...translationCache.entries()].slice(-1500);
        translationCache.clear();
        for (const [key, value] of entries) translationCache.set(key, value);
        localStorage.setItem(CACHE_NAME, JSON.stringify(Object.fromEntries(translationCache)));
      } catch {
        /* 放弃缓存 */
      }
    }
  }, 400);
}

/* ============================ 顶栏 / 交互 ============================ */

function bindUi() {
  ui.settingsBtn.addEventListener('click', openOptions);
  ui.setupAction.addEventListener('click', openOptions);
  ui.noticeClose.addEventListener('click', hideNotice);

  for (const button of ui.viewButtons) {
    button.addEventListener('click', () => applyViewMode(button.dataset.view));
  }

  ui.pagePrev.addEventListener('click', () => goToPage(state.currentPage - 1));
  ui.pageNext.addEventListener('click', () => goToPage(state.currentPage + 1));

  ui.pageInput.addEventListener('change', () => {
    const value = Number(ui.pageInput.value);
    if (Number.isFinite(value)) goToPage(value);
  });

  ui.pageInput.addEventListener('keydown', (event) => {
    if (event.key !== 'Enter') return;
    const value = Number(ui.pageInput.value);
    if (Number.isFinite(value)) goToPage(value);
  });

  ui.zoomIn.addEventListener('click', () => setZoom(state.zoom * 1.15));
  ui.zoomOut.addEventListener('click', () => setZoom(state.zoom / 1.15));
  ui.zoomLabel.addEventListener('click', () => setZoom(1));

  ui.translateBtn.addEventListener('click', () => {
    if (state.translating) {
      stopTranslation();
      return;
    }

    if (!hasTranslationConfig()) {
      showSetupBanner(true);
      showNotice('请先配置翻译服务：大模型填 API Key，百度填 AppID/密钥，或直接选 MyMemory。', [
        { label: '打开设置', onClick: openOptions },
      ]);
      openOptions();
      return;
    }

    const pending = state.pages.filter((p) => p.status !== 'done');
    if (!pending.length) {
      toast('全文已翻译完成');
      return;
    }
    startTranslation();
  });

  ui.viewport.addEventListener(
    'wheel',
    (event) => {
      if (!event.ctrlKey && !event.metaKey) return;
      event.preventDefault();
      setZoom(state.zoom * (event.deltaY < 0 ? 1.1 : 0.9));
    },
    { passive: false }
  );

  document.addEventListener('keydown', (event) => {
    if (!event.altKey) return;
    if (event.key === 'ArrowLeft') {
      event.preventDefault();
      goToPage(state.currentPage - 1);
    } else if (event.key === 'ArrowRight') {
      event.preventDefault();
      goToPage(state.currentPage + 1);
    }
  });

  let resizeTimer = 0;
  const onResize = () => {
    clearTimeout(resizeTimer);
    resizeTimer = window.setTimeout(() => {
      if (state.pages.length) applyLayout();
    }, 180);
  };

  window.addEventListener('resize', onResize);
  if (typeof ResizeObserver !== 'undefined') {
    new ResizeObserver(onResize).observe(ui.viewport);
  }
}

function onViewportScroll() {
  hideHoverTip();

  if (state.scrollTick) return;
  state.scrollTick = true;

  requestAnimationFrame(() => {
    state.scrollTick = false;

    const headerOffset = ui.viewport.getBoundingClientRect().top + 70;
    let current = 1;

    for (const p of state.pages) {
      const rect = p.row.getBoundingClientRect();
      if (rect.top <= headerOffset) current = p.n;
      else break;
    }

    updatePageIndicator(current);
  });
}

function goToPage(pageNumber) {
  if (!state.pages.length) return;

  const target = clamp(Math.round(pageNumber), 1, state.pages.length);
  const p = state.pages[target - 1];
  const viewportRect = ui.viewport.getBoundingClientRect();
  const rowRect = p.row.getBoundingClientRect();
  const top = ui.viewport.scrollTop + (rowRect.top - viewportRect.top) - 48;

  ui.viewport.scrollTo({ top: Math.max(0, top), behavior: 'smooth' });
  updatePageIndicator(target);
}

function updatePageIndicator(pageNumber) {
  const value = clamp(Math.round(pageNumber || 1), 1, Math.max(1, state.pages.length));
  state.currentPage = value;
  ui.pageInput.value = String(value);
  ui.pagePrev.disabled = value <= 1;
  ui.pageNext.disabled = value >= state.pages.length;
}

function updateTranslateButton() {
  const total = state.pages.length;
  const done = state.pages.filter((p) => p.status === 'done').length;
  const failed = state.pages.filter((p) => p.status === 'error').length;

  ui.translateSpinner.hidden = !state.translating;
  ui.translateBtn.classList.toggle('is-stop', state.translating);
  ui.translateBtn.classList.toggle('is-done', !state.translating && total > 0 && done === total);
  ui.translateBtn.disabled = !total || (!state.translating && total > 0 && done === total);

  if (state.translating) {
    ui.translateLabel.textContent = '停止翻译';
  } else if (total > 0 && done === total) {
    ui.translateLabel.textContent = '全部已译';
  } else if (done + failed > 0) {
    ui.translateLabel.textContent = '继续翻译';
  } else {
    ui.translateLabel.textContent = '翻译全文';
  }

  if (total) {
    const percent = (done / total) * 100;
    ui.progressLine.style.setProperty('--progress', `${percent}%`);
    ui.progressLine.hidden = !(state.translating || (done > 0 && done < total));
  } else {
    ui.progressLine.hidden = true;
  }
}

function showSetupBanner(show) {
  ui.setupBanner.hidden = !show;
}

function showNotice(text, actions = [], type = 'info') {
  ui.notice.hidden = false;
  ui.notice.classList.toggle('is-error', type === 'error');
  ui.noticeIcon.textContent = type === 'error' ? '!' : 'i';
  ui.noticeText.textContent = text;
  ui.noticeActions.textContent = '';

  for (const action of actions) {
    const button = document.createElement('button');
    button.type = 'button';
    button.textContent = action.label;
    button.addEventListener('click', action.onClick);
    ui.noticeActions.appendChild(button);
  }
}

function hideNotice() {
  ui.notice.hidden = true;
}

function showError(title, message, actions = []) {
  ui.loadingLayer.hidden = true;
  ui.errorLayer.hidden = false;
  ui.errorTitle.textContent = title;
  ui.errorText.textContent = message;
  ui.errorActions.textContent = '';

  for (const action of actions) {
    const button = document.createElement('button');
    button.type = 'button';
    button.textContent = action.label;
    if (action.primary) button.className = 'primary';
    button.addEventListener('click', action.onClick);
    ui.errorActions.appendChild(button);
  }
}

function setLoading(text, ratio, hint = '') {
  ui.loadingText.textContent = text;
  ui.loadingBar.style.width = `${clamp(ratio, 0, 1) * 100}%`;
  ui.loadingHint.textContent = hint;
}

function toast(message) {
  ui.toast.textContent = message;
  ui.toast.hidden = false;
  clearTimeout(state.toastTimer);
  state.toastTimer = window.setTimeout(() => {
    ui.toast.hidden = true;
  }, 2200);
}

function openOptions() {
  try {
    chrome.runtime.openOptionsPage();
  } catch {
    location.href = 'options.html';
  }
}

/* ============================ 工具函数 ============================ */

function createGate(limit) {
  let active = 0;
  const waiting = [];

  return {
    async acquire() {
      if (active < limit) {
        active += 1;
        return;
      }
      await new Promise((resolve) => waiting.push(resolve));
      active += 1;
    },
    release() {
      active = Math.max(0, active - 1);
      const next = waiting.shift();
      if (next) next();
    },
  };
}

async function mapLimit(items, limit, worker) {
  const results = new Array(items.length);
  let nextIndex = 0;

  const runners = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (true) {
      const index = nextIndex;
      nextIndex += 1;
      if (index >= items.length) return;
      results[index] = await worker(items[index], index);
    }
  });

  await Promise.all(runners);
  return results;
}

function median(values) {
  if (!values.length) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function readNumber(key, fallback) {
  const value = Number(localStorage.getItem(key));
  return Number.isFinite(value) && value > 0 ? value : fallback;
}

function readViewMode() {
  const value = localStorage.getItem('pr.view');
  return ['dual', 'original', 'translated'].includes(value) ? value : 'dual';
}

function fnv1a(text) {
  let hash = 0x811c9dc5;
  for (let i = 0; i < text.length; i += 1) {
    hash ^= text.charCodeAt(i);
    hash = Math.imul(hash, 0x01000193);
  }
  return (hash >>> 0).toString(36);
}

function cleanTitle(raw) {
  return String(raw || '')
    .replace(/^(microsoft\s+(word|powerpoint)\s*[-–—]\s*)/i, '')
    .replace(/\.(pdf|docx?|tex|dvi|rtf)$/i, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function fileNameFromUrl(url) {
  try {
    const name = new URL(url).pathname.split('/').filter(Boolean).pop() || '';
    return decodeURIComponent(name).replace(/\.pdf$/i, '');
  } catch {
    return '';
  }
}

function hostLabel(url) {
  try {
    const parsed = new URL(url);
    if (parsed.protocol === 'file:') return '本地文件';
    if (parsed.protocol === 'blob:') return '浏览器缓存文件';
    return parsed.hostname || parsed.protocol.replace(':', '');
  } catch {
    return '';
  }
}

function formatBytes(bytes) {
  if (!Number.isFinite(bytes) || bytes <= 0) return '';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}
